let logger = {
  configs: {
    debug: true,
    error: true,
    info: true,
    warn: true,
  },

  setConfig: function l_set(configs) {
    this.configs = {
      // verbose: false || configs.verbose,
      warn: false || configs.warn,
      error: true && configs.error,
      // graph: false || configs.graph,
      info: false || configs.info,
      debug: true && configs.debug,
      // reporter: configs.reporter || this.consoleReporter.bind(this)
    };
  },

  log: function l_log(tag, ...arg) {
    if (this.configs.debug) {
      console.log(tag, ...arg);
    }
  },

  debug: function l_debug(tag, message, value = "") {
    if (this.configs.debug) {
      console.debug(tag + " " + message + " " + value);
    }
  },

  error: function l_error(tag, message, value = "") {
    if (this.configs.error || this.configs.warn) {
      console.error(tag + " " + message + " " + value);
    }
  },

  info: function l_info(tag, message, value = "") {
    if (this.configs.info) {
      console.info(tag + " " + message + " " + value);
    }
  },

  warn: function l_warn(tag, message, value = "") {
    if (this.configs.warn) {
      console.warn(tag + " " + message + " " + value);
    }
  },
};
export default logger;
