import React, { useState } from 'react';
import PropTypes from 'prop-types';

import Tabs from '../../components/Tabs/Tabs';
import Tab from '../../components/Tab/Tab';

import './TabView.less';
const prefixCls = 'jps-tab-view';

const TabView = React.memo(
  props => {
    const {
      tabLabels,
      //onChangeIndex,
      //focusColor,
      children,
      onTabChange,
      current_Tab,
      isRecreated,
      isDialogOpen
    } = props;

    const [activeTab, setActiveTab] = useState(current_Tab);
    //const [isTransitionDone, setTransitionDone] = useState(true);

    const tabViewTabs = `${prefixCls}-tabs`;
    const tabViewContent = `${prefixCls}-content`;

    function handleChangeIndex(tabIndex) {
      // NOTE: Ensure you set state for tab transition first.
      //       Otherwise you will face strange race condition bugs.
      //setTransitionDone(false);
      onTabChange(tabIndex);
      setActiveTab(tabIndex);
      //onChangeIndex(tabIndex);
    };

    //const handleTransitionEnd = () => setTransitionDone(true);

    const renderTabs = () => {
      return tabLabels.map((label, i) => {
        return (
          <Tab
            key={`key-${i}`}
            label={label}
            //focusColor={focusColor}
          />
        );
      });
    };

    const renderChildren = () => {
      return React.Children.map(children, (child, i) => {
        if(activeTab === i){
          return React.cloneElement(child, {
            isActive: activeTab === i
          });
        }
      });
    };

    return (
      <div className={prefixCls}>
        <div className={tabViewTabs}>
          <Tabs onChangeIndex={handleChangeIndex} current_Tab={current_Tab} isRecreated={isRecreated} isDialogOpen={isDialogOpen}>
            {renderTabs()}
          </Tabs>
        </div>

        <div className={tabViewContent}>
          {renderChildren()}
        </div>
      </div>
    );
  }
);

TabView.propTypes = {
  tabLabels: PropTypes.arrayOf(PropTypes.string).isRequired,
  onChangeIndex: PropTypes.func,
  //focusColor: PropTypes.string,
  children: PropTypes.array,
  onTabChange: PropTypes.func,
  current_Tab:PropTypes.number,
  isRecreated:PropTypes.bool,
  isDialogOpen: PropTypes.bool,
};

TabView.defaultProps = {
  onChangeIndex: () => {},
  //focusColor: colors.defaultFocusColor,
};

export default TabView;
