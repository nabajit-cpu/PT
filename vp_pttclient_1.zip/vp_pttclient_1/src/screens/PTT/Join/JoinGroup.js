import React, { Component } from "react";
import loadable from "@loadable/component";

import Header from "../../../components/Header/Header";
import ListView from "../../../views/ListView/ListView";
import ArrowListItem from "../../../components/ArrowListItem/ArrowListItem";
import { SoftKeyProvider } from "../../../components/SoftKey/SoftKeyProvider";
import GroupType from "./GroupType";
import TextInput from "../../../components/TextInput/TextInput";
import Logger from "../../../utils/logger";
import Toast from "../../../components/Toast/Toast";
import PushToTalk from "../../../utils/push_to_talk";
import Dialog from "../../../components/Dialog/Dialog";
import { ChannelType, MessageType } from "../../../utils/channel_message_Type";
import { ConnectionStates, MediaStates } from "../../../utils/states";
import Connection from "../../../utils/connection";
import "../../../screens/screens.less";
const TAG = "Join Group:: ";

class JoinGroup extends Component {
  constructor(props) {
    super(props);
    if (props.isRecreated) {
      this.state.l_index = props.bundle.l_index;
      this.state.isRecreated = props.isRecreated;
    }
    this.joinPressed = this.joinPressed.bind(this);
    this.leavePressed = this.leavePressed.bind(this);
    this.speakData = this.speakData.bind(this);
    this.onListIndexChange = this.onListIndexChange.bind(this);
    this.userId = props.userId;
    this.serverURL = props.serverURL;
    this.company = props.company;
  }

  state = {
    groupType: true,
    toastMessage: "",
    displayToast: false,
    audioReceive: false,
    l_index: 0,
    joined: false,
    connected: true,
    senderId: null,
    speaking: false,
    showExitConfirmDialog: false,
  };

  componentDidMount() {
    document.addEventListener("keyup", (e) => {
      if (this.state.speaking) {
        console.log("Stopping listening");
        PushToTalk.stopTalking();
      }
    });
    if (window.localStorage.getItem("groupType") == "false") {
      this.setState({ groupType: false });
    } else {
      this.setState({ groupType: true });
    }
    window.addEventListener("MediaStates_" + MediaStates.StartListen, this);
    window.addEventListener("MediaStates_" + MediaStates.StopListen, this);
    window.addEventListener("ConnectionStates_" + ConnectionStates.Connected, this);
    window.addEventListener("ConnectionStates_" + ConnectionStates.Joined, this);
    window.addEventListener("ConnectionStates_" + ConnectionStates.Invalid, this);
    window.addEventListener("MediaStates_" + MediaStates.StartTalking, this);
    window.addEventListener("MediaStates_" + MediaStates.StopTallking, this);
    window.addEventListener("MediaStates_" + MediaStates.AudioPlayerStop, this);
  }

  componentWillUnmount() {
    console.log("componentWillUnmount");
    window.removeEventListener("MediaStates_" + MediaStates.StartListen, this);
    window.removeEventListener("MediaStates_" + MediaStates.StopListen, this);
    window.removeEventListener("ConnectionStates_" + ConnectionStates.Connected, this);
    window.removeEventListener("ConnectionStates_" + ConnectionStates.Joined, this);
    window.removeEventListener("ConnectionStates_" + ConnectionStates.Invalid, this);
    window.removeEventListener("MediaStates_" + MediaStates.StartTalking, this);
    window.removeEventListener("MediaStates_" + MediaStates.StopTallking, this);
    window.removeEventListener("MediaStates_" + MediaStates.AudioPlayerStop, this);
  }

  handleEvent = (evt) => {
    switch (evt.type) {
      case "MediaStates_" + MediaStates.StartListen:
        this.senderGroupType = "Group";
        this.senderId = evt.detail.userID;
        this.senderId = this.senderId.split("_")[1];
        this.setState({ audioReceive: true, senderId: evt.detail.userID });
        break;
      case "MediaStates_" + MediaStates.StopListen:
        document.getElementById("audioBar").classList.add("timelapse");
        break;
      case "MediaStates_" + MediaStates.StartTalking:
        this.setState({ speaking: true });
        break;
      case "MediaStates_" + MediaStates.StopTallking:
        this.setState({ speaking: false });
        break;
      case "MediaStates_" + MediaStates.AudioPlayerStop:
        document.getElementById("audioBar").classList.remove("timelapse");
        this.setState({ audioReceive: false });
        break;
      case "ConnectionStates_" + ConnectionStates.Connected:
        this.setState({ connected: true, joined: false });
        break;
      case "ConnectionStates_" + ConnectionStates.Joined:
        this.setState({ joined: true });
        break;
      case "ConnectionStates_" + ConnectionStates.Invalid:
        this.setState({
          connected: false,
          displayToast: true,
          toastMessage: "duplicateConnect",
        });
        setTimeout(() => {
          this.setState({ displayToast: false });
        }, 3000);
        window.componentManager.finish(this.props.identifier);
        break;
    }
  };

  getAlertsInfo = () => {};

  handleBack = () => {
    if (!this.state.showExitConfirmDialog) {
      this.setState({ showExitConfirmDialog: true });
    } else window.componentManager.finish(this.props.identifier);
  };

  onCancel = () => {
    this.setState({ showExitConfirmDialog: false });
  };

  onExit = () => {
    this.setState({ audioReceive: false });
    PushToTalk.leaveGroup(this.groupId);
    Connection.disconnect();
    window.componentManager.finish(this.props.identifier);
  };

  onTextEntered = (event) => {
    Logger.debug("text entered", event.target.id, event.target.value);
    switch (event.target.id) {
      case "groupId":
        this.groupId = event.target.value;
        // this.setState({ userID: event.target.value });
        break;
    }
  };

  itempressed = (navigatingparam) => {
    let properties = {};
    if (navigatingparam === "/groupType") {
      window.componentManager.registerComponent("/groupType", <GroupType />);
      properties = {
        isGroupEnabled: this.state.groupType,
      };
    }
    window.componentManager.startComponent(
      navigatingparam,
      properties,
      this.props.identifier,
      this.state,
      this.props
    );
  };
  disabledPressed = (navparam) => {};
  onListIndexChange(listIndex) {
    if (listIndex !== this.state.l_index) {
      this.setState({ l_index: listIndex });
    }
  }

  joinPressed() {
    if (!this.state.showExitConfirmDialog && this.groupId) {
      console.log(
        "Join Pressed " + " user " + this.userId + " company " + this.company + "server url ",
        this.serverURL
      );
      PushToTalk.joinGroup(this.groupId);
      this.setState({
        displayToast: true,
        toastMessage: "joined",
      });
      setTimeout(() => {
        this.setState({ displayToast: false });
      }, 3000);
    } else {
      this.setState({
        displayToast: true,
        toastMessage: "noGroup",
      });
      setTimeout(() => {
        this.setState({ displayToast: false });
      }, 3000);
    }
  }
  leavePressed() {
    console.log(
      "Leave Pressed " + " user " + this.userId + " company " + this.company + "server url ",
      this.serverURL
    );
    if (this.state.speaking) {
      PushToTalk.stopTalking();
    }
    this.setState({
      displayToast: true,
      toastMessage: "left",
    });
    setTimeout(() => {
      this.setState({ displayToast: false });
    }, 3000);
    PushToTalk.leaveGroup(this.groupId);
    document.getElementById("groupId").focus();
  }

  speakData() {
    if (!this.state.speaking) {
      this.setState({
        displayToast: true,
        toastMessage: "speaking",
      });
      setTimeout(() => {
        this.setState({ displayToast: false });
      }, 3000);
      PushToTalk.startTalking(this.groupId, ChannelType.GROUP, () => {});
    } else {
      console.log("Stopping listening");
      PushToTalk.stopTalking();
    }
  }

  render() {
    return (
      <div className="App">
        {!this.state.audioReceive ? (
          <>
            <Header
              labelText={"User ID :" + this.userId}
              secondaryLabelText={"Company:" + this.company}
            />
            <SoftKeyProvider
              backCallback={this.handleBack}
              left={this.state.groupType ? "join" : "space"}
              right={this.state.joined ? "leave" : this.state.connected ? "exit" : "space"}
              center={
                this.state.joined || !this.state.groupType
                  ? this.state.speaking
                    ? "speaking"
                    : "speak"
                  : "space"
              }
              centerCallback={this.state.joined ? this.speakData : null}
              leftCallback={this.state.groupType ? this.joinPressed : null}
              rightCallback={
                this.state.joined
                  ? this.leavePressed
                  : this.state.connected
                  ? this.handleBack
                  : null
              }
            >
              <ListView
                callback={this.itempressed}
                currentIndex={this.state.l_index}
                isRecreated={this.state.isRecreated}
                onChangeIndex={this.onListIndexChange}
                disabledCallback={this.disabledPressed}
              >
                <TextInput
                  label="serverURL"
                  id="serverUrl"
                  placeholder="Server URL"
                  value=""
                  disabledInput={this.serverURL}
                  onChange={() => {}}
                  onFocusChange={() => {}}
                  initialValue=""
                />
                <TextInput
                  label="connectionState"
                  id="connectionState"
                  placeholder="connectionState"
                  value="Connected"
                  initValue=""
                />
                <ArrowListItem
                  primary="channelType"
                  secondary={this.state.groupType ? "group" : "private"}
                  toPath="/groupType"
                />
                {!this.state.joined ? (
                  <TextInput
                    label="group-id"
                    id="groupId"
                    placeholder="Group id"
                    onChange={this.onTextEntered}
                    initValue=""
                  />
                ) : (
                  <TextInput
                    label="group-id"
                    id="groupId"
                    placeholder="Group id"
                    onChange={this.onTextEntered}
                    initValue=""
                    disabledInput={this.groupId}
                  />
                )}
              </ListView>
            </SoftKeyProvider>
          </>
        ) : (
          <>
            <Header
              labelText={"User ID :" + this.userId}
              secondaryLabelText={"Company:" + this.company}
            />
            <SoftKeyProvider
              left={"space"}
              center={"space"}
              right={"exit"}
              rightCallback={this.handleBack}
            >
              <div id="receiveDetails">
                <div>{"Incoming"}</div>
                <div>{this.senderGroupType}</div>
                <div>{this.senderId}</div>
              </div>

              <div id="progress-bar-container">
                <div class="progress-bar-child progress"></div>
                <div class="progress-bar-child shrinker" id="audioBar"></div>
              </div>
            </SoftKeyProvider>
          </>
        )}
        <Toast toastMessage={this.state.toastMessage} displayToast={this.state.displayToast} />
        {this.state.showExitConfirmDialog ? (
          <Dialog
            showDialog={this.state.showExitConfirmDialog}
            leftText="cancel"
            rightText="ok"
            bodyText={<div data-l10n-id="confirm-exit"></div>}
            leftCall={this.onCancel}
            rightCall={this.onExit}
            headerText="exit"
          />
        ) : null}
      </div>
    );
  }
}

export default JoinGroup;
