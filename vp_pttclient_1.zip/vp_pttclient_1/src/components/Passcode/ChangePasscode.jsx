import React, { Component } from 'react';
import './Passcode.less';
import PropTypes from "prop-types";
import Logger from "../../utils/logger"

const TAG = "ChangePasscode:: "
class ChangePasscode extends Component {
    constructor(props) {
        super(props);
        this.qwertyKeyMapping = {
            'w': '1', 'e': '2', 'r': '3', 's': '4', 'd': '5',
            'f': '6', 'z': '7', 'x': '8', 'c': '9', ',': '0'
        };
        this.state = {
            values: [],
            isfocusedRow1: true,
            isfocusedRow2: false,
            isfocusedRow3: false,
        }
    }

    componentDidMount(){
        document.addEventListener('keydown', this.handleEvent);
    }


    translateKey = (key) => {
        Logger.debug(TAG , "qwertyKeyMapping "+ this.qwertyKeyMapping[key]);
        return this.qwertyKeyMapping[key] || key;
    }

    handleEvent = (e) => {
        Logger.debug(TAG , "handle event id ");

        let dialogOpened = this.props.isDialogOpen
        if (dialogOpened) {
            e.preventDefault();
            e.stopPropagation();
        } else {
            //var keyCode = e.key;
            var keyCode = this.translateKey(e.key);
            Logger.debug(TAG , "handle keyCode ");
            if (!(keyCode >= '0' && keyCode <= '9') && keyCode != 'Backspace') {
                e.preventDefault();
                return false;
            } else {
                if (keyCode == 'Backspace') {
                    this.setState((state, props) => {
                        let newValues = [...state.values]
                        newValues.pop()
                        return {
                            values: newValues
                        }
                    });
                    this._updatePassCodeUI();
                    e.stopPropagation();
                    if (this.state.values.length === 0) {
                        document.removeEventListener('keydown', this.handleEvent);
                        this.props.onExit();
                    }
                    e.preventDefault();
                } else {
                    this.state.values.push(keyCode);
                    if (this.state.values.length < 13) {
                        this._updatePassCodeUI();
                        if (this.state.values.length === 12) {
                            this.passcodeLogic();
                        }
                    }
                }
            }

        }

    }

    _updatePassCodeUI = () => {
        //   this.posscodeInput.classList.add('highlight');
        //  this.posscodeConfirmInput.classList.remove('highlight');
        for (var i = 0; i < 12; i++) {
            if (i < this.state.values.length) {
                if (i < 3) {
                    this.setState({
                        isfocusedRow1: true,
                        isfocusedRow2: false,
                        isfocusedRow3: false
                    });
                } else if ((i <= 7) && (i >= 3)) {
                    this.setState({
                        isfocusedRow1: false,
                        isfocusedRow2: true,
                        isfocusedRow3: false
                    });
                } else if ((i <= 12) && (i >= 8)) {
                    this.setState({
                        isfocusedRow1: false,
                        isfocusedRow2: false,
                        isfocusedRow3: true
                    });
                }
                document.getElementById("pin-" + (i + 1)).dataset.dot = true;
            } else {
                delete document.getElementById("pin-" + (i + 1)).dataset.dot;
            }
        }
    }

    passcodeLogic = () => {

        let newValues = [...this.state.values];
        this.props.onPinSet(newValues);
        let match = true
        for (let i = 0; i < 4; i++) {
            if (newValues[i + 4] != newValues[i + 8]) {
                match = false;
                break;
            }
        }

        if (!match) {
            this.setState((state, props) => {
                let newValues = [...state.values]
                for (let i = 4; i < 12; i++) {
                    newValues.pop();
                }
                this.setState({
                    isfocusedRow1: false,
                    isfocusedRow2: true,
                    isfocusedRow3: false
                });
                
                return {
                    values: newValues
                }

            });

        } else {
            this.setState((state, props) => {
                let newValues = [...state.values]
                for (let i = 0; i < 12; i++) {
                    newValues.pop();
                }
                this.setState({
                    isfocusedRow1: true,
                    isfocusedRow2: false,
                    isfocusedRow3: false,
                });

                return {
                    values: newValues
                }
            });
        }
        this._updatePassCodeUI();
        return

    }

    componentWillUnmount(){
        document.removeEventListener('keydown', this.handleEvent);
    }

    inputElementRenderMethod = (i) => {
        return <span className="passcode-digit"

            name={"pin-" + (i + 1)}
            id={"pin-" + (i + 1)}
            key={"pin-" + (i + 1)}

        />;
    }


    renderLockScreenUI = () => {
        let inputs1 = [...Array(4).keys()].map(function (i) {
            if (i === 0) {
                return (
                    <div>
                        {this.state.isfocusedRow1 ? <span className="passcode-span-focus" data-l10n-id="callBarring-current-passcode"></span>
                            : <span className="passcode-span-unfocus" data-l10n-id="callBarring-current-passcode"></span>}
                        {this.inputElementRenderMethod(i)}
                    </div>);
            } else {
                return this.inputElementRenderMethod(i);
            }

        }.bind(this)
        );

        let inputs2 = [...Array(4).keys()].map(function (j) {
            j = j + 4;
            if (j === 4) {
                return (
                    <div >
                        {this.state.isfocusedRow2 ? <span className="passcode-span-focus" ddata-l10n-id="callBarring-create-passcode"></span>
                            : <span className="passcode-span-unfocus" data-l10n-id="callBarring-create-passcode"></span>}
                        {this.inputElementRenderMethod(j)}
                    </div>);
            } else {
                return this.inputElementRenderMethod(j);
            }
        }.bind(this)
        );

        let inputs3 = [...Array(4).keys()].map(function (k) {
            k = k + 8;
            if (k === 8) {
                return (
                    <div >
                        {this.state.isfocusedRow3 ? <span className="passcode-span-focus" ddata-l10n-id="confirm-the-passcode"></span>
                            : <span className="passcode-span-unfocus" data-l10n-id="callBarring-confirm-passcode"></span>}
                        {this.inputElementRenderMethod(k)}
                    </div>);
            } else {
                return this.inputElementRenderMethod(k);
            }
        }.bind(this)
        );

        return (
            <div>
                {
                    this.state.isfocusedRow1 ? <div className="passcode-focus">  {inputs1}
                    </div> : <div className="passcode-unfocus">  {inputs1}
                        </div>
                }

                {
                    this.state.isfocusedRow2 ? <div className="passcode-focus">  {inputs2}
                    </div> : <div className="passcode-unfocus">  {inputs2}
                        </div>
                }
                {
                    this.state.isfocusedRow3 ? <div className="passcode-focus">  {inputs3}
                    </div> : <div className="passcode-unfocus">  {inputs3}
                        </div>
                }</div>);
    }

    render() {
        let inputs = [...Array(12).keys()].map(function (i) {
            if (i === 0) {
                return (
                    <div>
                        <span className="passcode-span-unfocus" data-l10n-id="callBarring-current-passcode"></span>
                        {this.inputElementRenderMethod(i)}
                    </div>);
            } else if (i === 4) {
                return (
                    <div>
                        <span className="passcode-span-unfocus" data-l10n-id="callBarring-create-passcode"></span>
                        {this.inputElementRenderMethod(i)}
                    </div>);
            } else if (i === 8) {
                return (
                    <div>
                        <span className="passcode-span-unfocus" data-l10n-id="callBarring-confirm-passcode"></span>
                        {this.inputElementRenderMethod(i)}
                    </div>);
            } else {
                return this.inputElementRenderMethod(i);
            }

        }.bind(this)
        );


        return (
            <div className="passcode-container">

                {!this.props.isLockScreen ? <div className="passcode">
                    {inputs}
                </div> : this.renderLockScreenUI()}

            </div>
        );
    }
};

ChangePasscode.propTypes = {
    isDialogOpen: PropTypes.bool,
    isLockScreen: PropTypes.bool,
    // updateFunction: PropTypes.func,
};

ChangePasscode.defaultProps = {
    isDialogOpen: false,
    isLockScreen: false,
}

export default ChangePasscode;



