import React, { Component } from 'react';
import './Passcode.less';
import Paragraph from '../Paragraph/Paragraph';
import Logger from "../../utils/logger"

const TAG = "Passcode:: "
class Passcode extends Component {
    constructor(props) {
        super(props);
        this.qwertyKeyMapping = {
            'w': '1', 'e': '2', 'r': '3', 's': '4', 'd': '5',
            'f': '6', 'z': '7', 'x': '8', 'c': '9', ',': '0'
        };
        this.state = {
            values: []
        }
        document.addEventListener('keydown', this.handleEvent);
    }

    componentDidMount(){
        document.addEventListener('keydown', this.handleEvent);
    }
    
    translateKey = (key) => {
        Logger.debug(TAG , "qwertyKeyMapping "+ this.qwertyKeyMapping[key]);
        return this.qwertyKeyMapping[key] || key;
    }

    handleEvent = (e, id) => {
        Logger.debug(TAG , "handle event id" + e.keyCode);

        var keyCode = this.translateKey(e.key);
        if (!(keyCode >= '0' && keyCode <= '9') && keyCode != 'Backspace') {
            e.preventDefault();
            return false;
        } else {
            if (keyCode == 'Backspace') {
                document.removeEventListener('keydown', this.handleEvent);
                e.stopPropagation();
                e.preventDefault();
            } else {
                this.state.values.push(keyCode);
                if (this.state.values.length <= 4) {
                    this._updatePassCodeUI();
                    if (this.state.values.length === 4) {
                        this.passcodeLogic();
                    }
                }
            }

        }
    }

    _updatePassCodeUI = () => {

        for (var i = 0; i < 4; i++) {
            if (i < this.state.values.length) {
                document.getElementById("pin-" + (i + 1)).dataset.dot = true;
            } else {
                delete document.getElementById("pin-" + (i + 1)).dataset.dot;
            }

        }
    }

    componentWillUnmount(){
        document.removeEventListener('keydown', this.handleEvent);
    }

    passcodeLogic = () => {
        let newValues = [...this.state.values];
        this.props.onPasscodeSet(newValues);

        this.setState((state, props) => {
            let newValues = [...state.values]
            for (let i = 0; i < 4; i++) {
                newValues.pop();
            }

            return {
                values: newValues
            }

        });

        this._updatePassCodeUI();
        return

    }

    render() {

        let inputs = [...Array(4).keys()].map((i) => {
            return <span className="passcode-digit"
                name={"pin-" + (i + 1)}
                id={"pin-" + (i + 1)}
            />;
        });

        return (
            <div className="passcode-container">
                <div className="passcode-unfocus">
                    {inputs}
                </div>
                <Paragraph text="callBarring-passcode-unknown" isItalic={false} />
            </div>

        );
    }
};

export default Passcode;



