import React, { Component } from 'react';
import { useFocus, useRef, useEffect } from '../../hooks';
import PropTypes from "prop-types";
import './CreatePasscode.less';
import Logger from "../../utils/logger";

const TAG= "VerifyPasscode:: "

class VerifyPasscode extends Component {
    constructor(props) {
        super(props);
        this.qwertyKeyMapping = {
            'w': '1', 'e': '2', 'r': '3', 's': '4', 'd': '5',
            'f': '6', 'z': '7', 'x': '8', 'c': '9', ',': '0'
        };
        this.state = {
            values: [],
        }
    }
    
    componentDidMount(){
        document.addEventListener('keydown', this.handleEvent);
    }

    translateKey = (key) => {
        Logger.debug(TAG , "qwertyKeyMapping "+ this.qwertyKeyMapping[key]);
        return this.qwertyKeyMapping[key] || key;
    }

    handleEvent = (e, id) => {
        Logger.debug(TAG , "handle event id" + e.keyCode);
        let dialogOpened = this.props.isDialogOpen
        if (dialogOpened) {
            e.preventDefault();
            e.stopPropagation();
        } else {
            var keyCode = this.translateKey(e.key);
            Logger.debug(TAG , "handle keyCode " + e.key);
            if (!(keyCode >= '0' && keyCode <= '9') && keyCode != 'Backspace') {
                e.preventDefault();
                return false;
            } else {
                if (keyCode == 'Backspace') {
                    this.setState((state, props) => {
                        let newValues = [...state.values]
                        newValues.pop()
                        return {
                            values: newValues
                        }
                    });
                    this._updatePassCodeUI();
                    e.stopPropagation();
                    if (this.state.values.length === 0) {
                        document.removeEventListener('keydown', this.handleEvent);
                        this.props.onExit();
                    }
                    e.preventDefault();
                } else {
                    this.state.values.push(keyCode);
                    if (this.state.values.length <= 4) {
                        this._updatePassCodeUI();
                        if (this.state.values.length === 4) {
                            this.passcodeLogic();
                        }
                    }
                }
            }

        }

    }

    _updatePassCodeUI = () => {

        for (var i = 0; i < 4; i++) {
            if (i < this.state.values.length) {
                document.getElementById("pin-" + (i + 1)).dataset.dot = true;
            } else {
                delete document.getElementById("pin-" + (i + 1)).dataset.dot;
            }

        }
    }

    passcodeLogic = () => {

        let newValues = [...this.state.values];
        this.props.onPasscodeSet(newValues);

        this.setState((state, props) => {
            let newValues = [...state.values]
            for (let i = 0; i < 4; i++) {
                newValues.pop();
            }

            return {
                values: newValues
            }

        });

        this._updatePassCodeUI();
        return

    }

    componentWillUnmount(){
        document.removeEventListener('keydown', this.handleEvent);
    }

    render() {

        let inputs = [...Array(4).keys()].map((i) => {
            return <span className="create-passcode-digit"
                name={"pin-" + (i + 1)}
                id={"pin-" + (i + 1)}
            />;
        });

        return (
            <div className="create-passcode-container">
                <div className="create-passcode-focus">
                    {inputs}
                </div>
            </div>

        );
    }
};

VerifyPasscode.propTypes = {
    isDialogOpen: PropTypes.bool,
    // updateFunction: PropTypes.func,
};

VerifyPasscode.defaultProps = {
    isDialogOpen: false,
}

export default VerifyPasscode;



