import React from "react";
import PropTypes from "prop-types";
import "./Header.less";

const prefixCls = "jps-header";
const Header = React.memo((props) => {
  const { text, backgroundColor, labelText, secondaryLabelText } = props;

  return (
    <header className={prefixCls} style={{ background: backgroundColor }}>
      {labelText ? (
        <>
          <h1 className="h1">{labelText}</h1>
          {secondaryLabelText ? <h7 className="h7">{secondaryLabelText}</h7> : ""}
        </>
      ) : (
        <h1 className="h1" data-l10n-id={text}>
          {text}
        </h1>
      )}
    </header>
  );
});

Header.propTypes = {
  text: PropTypes.string.isRequired,
  backgroundColor: PropTypes.string,
  labelText: PropTypes.string,
  secondaryLabelText: PropTypes.string,
};

Header.defaultProps = {
  backgroundColor: "#ff0000",
  labelText: null,
  secondaryLabelText: null,
};

export default Header;
