import React from "react";

import { SoftKeyProvider } from "../SoftKey/SoftKeyProvider";

import "./DatePickerDialog.less";
import Header from "../Header/Header";
import PropTypes from "prop-types";
import TriColListView from "../../views/TriColListView/TriColListView";
import BodyTextListItem from "../BodyTextListItem/BodyTextListItem";
import Logger from "../../utils/logger";
const TAG = "ES:: DatePickerDialog:: ";

class DatePickerDialog extends React.Component {
  constructor(props) {
    super(props);
    // this.currentmonth = this.currentDate.getMonth() + 1;
    // this.currentDay = this.currentDate.getDate();
    // const yearPrevious = currentyear - 50;
    // const yearNext = currentyear + 50;

    this.Months = {
      Jan: 1,
      Feb: 2,
      Mar: 3,
      Apr: 4,
      May: 5,
      June: 6,
      Jul: 7,
      Aug: 8,
      Sep: 9,
      Oct: 10,
      Nov: 11,
      Dec: 12,
    };
    Object.freeze(this.Months);

    let minYear = this.props.initialDate.getFullYear() - 50;
    let maxYear = this.props.initialDate.getFullYear() + 50;

    let years = [];
    for (let i = minYear; i <= maxYear; i++) {
      years.push(i);
    }

    const minDay = 1;
    const maxDay = this.daysInMonth(
      this.props.initialDate.getMonth() + 1,
      this.props.initialDate.getFullYear()
    );
    const days = [];
    for (let i = minDay; i <= maxDay; i++) {
      days.push(i);
    }

    const months = Object.keys(this.Months);

    this.state = {
      years: years,
      months: months,
      days: days,
      selectedDay: this.props.initialDate.getDate(),
      selectedMonth: this.props.initialDate.getMonth(),
      selectedYear: this.props.initialDate.getFullYear(),
    };
  }

  componentWillReceiveProps(props) {
    let minYear = this.props.initialDate.getFullYear() - 50;
    let maxYear = this.props.initialDate.getFullYear() + 50;
    const years = [];
    for (let i = minYear; i <= maxYear; i++) {
      years.push(i);
    }
    this.setState({ years: years, });
  }

  daysInMonth = (month, year) => {
    return new Date(year, month, 0).getDate();
  };

  setYear = (index) => {
    this.setState({
      selectedYear: this.state.years[index],
    });
    this.resetDaysForNewMonthYear();
  };

  setMonth = (index) => {
    this.setState({
      selectedMonth: index,
    });
    this.resetDaysForNewMonthYear();
  };

  setDay = (index) => {
    this.setState({
      selectedDay: this.state.days[index],
    });
  };

  okSelected = () => {
    this.props.centerCall(this.calcSelectedDate());
  };

  resetDaysForNewMonthYear() {
    const minDay = 1;
    const maxDay = this.daysInMonth(
      this.state.selectedMonth + 1,
      this.state.selectedYear
    );
    const days = [];
    for (let i = minDay; i <= maxDay; i++) {
      days.push(i);
    }

    this.setState({ days });

    if (this.state.selectedDay > maxDay) {
      this.setState({
        selectedDay: maxDay,
      });
    }
  }

  calcSelectedDate = () => {
    Logger.debug(TAG , "calcSelectedDate selectedYear : " + this.state.selectedYear);
    Logger.debug(TAG , "selectedMonth : " + this.state.selectedMonth);
    Logger.debug(TAG , "selectedDay : " + this.state.selectedDay);

    return new Date(
      this.state.selectedYear,
      this.state.selectedMonth,
      this.state.selectedDay
    );
  };

  render() {
    if (this.props.showDialog) {
      let yearIndex = this.state.years.indexOf(
        this.props.initialDate.getFullYear()
      );
      return (
        <div className="root-dialog">
          <div className="Dialog">
            <Header text={this.props.headerText} />
            <SoftKeyProvider
              left={this.props.leftText}
              center={this.props.centerText}
              centerCallback={this.okSelected}
              leftCallback={this.props.leftCall}
            >
              <div className="contentdialog">
                <TriColListView
                  col1Children={this.state.months.map((item, i) => (
                    <BodyTextListItem header={item.toString()} index={i} l10nId={"month-"+`${i}`+"-short"}/>
                  ))}
                  col2Children={this.state.days.map((item, i) => (
                    <BodyTextListItem header={item.toString()} index={i} />
                  ))}
                  col3Children={this.state.years.map((item, i) => (
                    <BodyTextListItem header={item.toString()} index={i} />
                  ))}
                  onCol1ChangeIndex={(index) => this.setMonth(index)}
                  onCol2ChangeIndex={(index) => this.setDay(index)}
                  onCol3ChangeIndex={(index) => this.setYear(index)}
                  selectedCol1Index={this.props.initialDate.getMonth()}
                  selectedCol2Index={this.props.initialDate.getDate() - 1}
                  selectedCol3Index={yearIndex}
                />
              </div>
            </SoftKeyProvider>
          </div>
        </div>
      );
    } else {
      return <div></div>;
    }
  }
}

DatePickerDialog.propTypes = {
  leftText: PropTypes.string,
  centerText: PropTypes.string,
  leftCall: PropTypes.func,
  centerCall: PropTypes.func,
  headerText: PropTypes.string,
  initialDate: PropTypes.instanceOf(Date).isRequired,
  // updateFunction: PropTypes.func,
};

export default DatePickerDialog;
