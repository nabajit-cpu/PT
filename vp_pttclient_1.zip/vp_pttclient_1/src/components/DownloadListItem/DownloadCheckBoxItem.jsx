import React, { useEffect, useState, useCallback } from 'react';
import PropTypes from 'prop-types';
import { SoftKeyConsumer } from '../SoftKey/withSoftKeyManager';
import './DownloadCheckBoxItem.less';
import failedDownloadIcon from "../../assets/ic_failed_download.svg";
import Logger from "../../utils/logger"

const prefixCls = 'jps-dcbl';
const TAG= "DownloadCheckBoxItem:: "
const DownloadCheckBoxItem = React.memo(props => {
  const {
    id,
    primary,
    secondary,
    initCheckboxVal,
    onInputChange,
    checkboxSide,
    focusColor,
    onFocusChange,
    index,
    forwardedRef,
    softKeyManager,
    softKeyCheckedText,
    softKeyUncheckedText,
    softKeyCheckedIcon,
    softKeyUncheckedIcon,
    secondaryText,
    primaryText,
    tertiaryText,
    tertiary,
    itemdisabled,
    checkboxEnabled,
    percentage,
    percent,
    percentText,
    byte,
    byteText,
    failedIcon,
  } = props;



  // Managed vs self-managed radio buttons
  const [isChecked, setChecked] = useState(initCheckboxVal);
  const [isFocused, setFocused] = useState(false);

  const itemCls = prefixCls;
  const boxCls = `${prefixCls}-box`;
  const failBoxCls = `${prefixCls}-failed-box`;
  const lineCls = `${prefixCls}-line ${checkboxSide === 'left' ? 'right' : 'left'
    }`;
  const primaryCls = `${prefixCls}-primary`;
  const secondaryCls = `${prefixCls}-secondary ${secondary ? '' : 'hidden'}`;
  const tertiaryCls = `${prefixCls}-tertiary`;

  const inputCls = `${boxCls}-input-${isFocused ? 'focused' : 'unfocused'}`;

  const barCls = `${prefixCls}-bar`;
  const progressLeftTextCls = `${prefixCls}-bar-left-text`;
  const progressRightTextCls = `${prefixCls}-bar-right-text`;
  const barWrapperCls = `${prefixCls}-bar-wrapper`;
  const leftFillerCls = `${prefixCls}-left-filler`;
  const rightFillerCls = `${prefixCls}-right-filler-download-${isFocused ? 'focused' : 'unfocused'
    }`;


  useEffect(() => {
    const centerText = isChecked ? softKeyCheckedText : softKeyUncheckedText;
    const centerIcon = isChecked ? softKeyCheckedIcon : softKeyUncheckedIcon;
    if (isFocused) {
      if (centerIcon != null) {
        softKeyManager.setCenterIcon(centerIcon);
      } else {
        softKeyManager.setCenterText(centerText);
      }
    }
  }, [
    isFocused,
    isChecked,
    softKeyManager,
    softKeyCheckedText,
    softKeyUncheckedText,
    softKeyCheckedIcon,
    softKeyUncheckedIcon,
  ]);


  React.useEffect(() => {
    setChecked(props.initCheckboxVal);
  }, [props.initCheckboxVal])

  const handleInvertCheck = () => setChecked(wasChecked => !wasChecked);

  const handleInputChange = (e) => {
    setChecked(e.target.checked);
    if (onInputChange) {
      onInputChange(e.target.checked);
    }
  };

  // We want to avoid losing focus on the parent element
  const handleCheckFocus = e => {
    e.preventDefault();
    if (e.relatedTarget) {
      // Revert focus back to previous blurring element
      e.relatedTarget.focus();
    } else {
      // No previous focus target, blur instead
      e.currentTarget.blur();
    }
  };

  const handleFocusChange = useCallback(
    isNowFocused => {
      setFocused(isNowFocused);
      if (isNowFocused) {
        if (checkboxEnabled) {
          const centerText = isChecked
            ? softKeyCheckedText
            : softKeyUncheckedText;
          const centerIcon = isChecked
            ? softKeyCheckedIcon
            : softKeyUncheckedIcon;
          if (centerIcon != null) {
            softKeyManager.setCenterIcon(centerIcon);
          } else {
            softKeyManager.setCenterText(centerText);
          }
          softKeyManager.setCenterCallback(handleInvertCheck);
        }
        onFocusChange(index);
      }
    },
    [
      index,
      onFocusChange,
      isChecked,
      softKeyCheckedText,
      softKeyUncheckedText,
      softKeyCheckedIcon,
      softKeyUncheckedIcon,
      softKeyManager,
    ]
  );

  const checkbox = (
    <div className={boxCls}>
      <input

        className={inputCls}
        tabIndex={-1}
        type="checkbox"
        checked={isChecked}
        onFocus={handleCheckFocus}
        onChange={handleInputChange}
        itemdisabled={itemdisabled}
      />
    </div>
  );

  const failedDownloadBox = (
    <div className={failBoxCls}>
      <img  src={failedDownloadIcon} alt="" width="24" height="24"/>
      </div>
  );

  return (
    <div
      id={id}
      tabIndex={0}
      className={itemCls}
      style={{ backgroundColor: isFocused ? (focusColor || "#0E4B9B") : "#FFFFFF" }}
      ref={forwardedRef}
      onFocus={() => handleFocusChange(true)}
      onBlur={() => handleFocusChange(false)}
      itemdisabled={itemdisabled}
    >
      {failedIcon?failedDownloadBox:null}
      {checkboxSide === 'left' ? checkbox : null}
      <div className={lineCls}>
        {primaryText ? (
          <span
            className={
              primaryCls
            }
          >
            {primaryText}
          </span>
        ) : (
            <span
              data-l10n-id={primary}
              className={
                primaryCls
              }
            >

            </span>
          )
        }

        {(secondary || secondaryText) ? (
          secondaryText ?
            (<label
              className={secondaryCls}
            >
              {secondaryText}
            </label>) :
            (<label
              data-l10n-id={secondary}
              className={secondaryCls}
            >
            </label>)
        ) : (
            ""
          )

        }

        {(tertiary || tertiaryText) ? (
          tertiaryText ?
            (<label className={tertiaryCls}>
              {tertiaryText}
            </label>) :
            (<label
              data-l10n-id={tertiary}
              className={tertiaryCls}
            >
            </label>)
        ) : (
            ""
          )

        }

        {percentage != null ?
          <div className={barCls}>
            {(percent || percentText) ? (
              percentText ?
                (<label
                  className={progressLeftTextCls}
                >
                  {percentText}
                </label>) :
                (<label
                  data-l10n-id={percent}
                  className={progressLeftTextCls}
                >
                </label>)
            ) : (
                ""
              )

            }

            {(byte || byteText) ? (
              byteText ?
                (<label className={progressRightTextCls}>
                  {byteText}
                </label>) :
                (<label
                  data-l10n-id={byte}
                  className={progressRightTextCls}
                >
                </label>)
            ) : (
                ""
              )

            }
            <div className={barWrapperCls}>
              <div
                className={leftFillerCls}
                style={{
                  width: `${percentage}%`,
                  backgroundColor: isFocused ? "#00FFFF" : ("#0E4B9B" || "#FFFFFF"),
                }}
              />
              <div
                className={rightFillerCls}
                style={{ width: `${100 - percentage}%` }}
              />
            </div>
          </div> : ""}



      </div>
      {checkboxSide === 'right' ? checkbox : null}
    </div>
  );
});
DownloadCheckBoxItem.propTypes = {
  primary: PropTypes.string,
  secondary: PropTypes.string,
  // Used for unmanaged checkboxes
  initCheckboxVal: PropTypes.bool.isRequired,
  onInputChange: PropTypes.func.isRequired,
  // For direct management over the checkbox value
  isChecked: PropTypes.bool,
  onChecked: PropTypes.bool,
  checkboxSide: PropTypes.oneOf(['left', 'right', '']).isRequired,
  focusColor: PropTypes.string,
  checkboxEnabled: PropTypes.bool,
  // For ListView navigation
  onFocusChange: PropTypes.func,
  index: PropTypes.number,
  forwardedRef: PropTypes.oneOfType([
    PropTypes.func,
    PropTypes.shape({ current: PropTypes.any }),
    PropTypes.ref
  ]),

  // For softkey
  softKeyCheckedText: PropTypes.string,
  softKeyUncheckedText: PropTypes.string,
  softKeyCheckedIcon: PropTypes.string,
  softKeyUncheckedIcon: PropTypes.string,
  secondaryText: PropTypes.string,
  primaryText: PropTypes.string,
  tertiaryText: PropTypes.string,
  tertiary: PropTypes.string,
  percentage: PropTypes.number,
  percent: PropTypes.string,
  percentText: PropTypes.string,
  byte: PropTypes.string,
  byteText: PropTypes.string,
  failedIcon: PropTypes.bool,
};

DownloadCheckBoxItem.defaultProps = {
  primary: null,
  secondary: null,
  secondaryText: null,
  primaryText: null,
  isChecked: null,
  focusColor: "#0E4B9B",
  softKeyCheckedText: 'Deselect',
  softKeyUncheckedText: 'Select',
  itemdisabled: "enabled",
  softKeyCheckedIcon: null,
  softKeyUncheckedIcon: null,
  tertiaryText: null,
  tertiary: null,
  checkboxEnabled: false,
  percentage: null,
  percent: null,
  percentText: null,
  byte: null,
  byteText: null,
  failedIcon: false,
};
export default React.forwardRef((props, ref) => (
  <SoftKeyConsumer>
    {context => (
      <DownloadCheckBoxItem
        softKeyManager={context}
        forwardedRef={ref}
        {...props}
      />
    )}
  </SoftKeyConsumer>
));
