import React from "react";
import PropTypes from "prop-types";

import "./Separator.less";

const prefixCls = "jps-separator";
const Separator=React.memo((props)=> {
  return (
    <div className={prefixCls}>
      <span className={`${prefixCls}-text`} data-l10n-id={props.separatorText}>{props.separatorText}</span>
    </div>
  );
});

Separator.propTypes={
  separatorText: PropTypes.string,
};

export default Separator;
