import React, { useState, useEffect } from "react";

import "./Toast.less";
import PropTypes from "prop-types";

// const Toast = (props) => {
//   const { toastMessage, displayToast } = props;
//   if (displayToast == true)
//     return (
//       <div className={`toast-container `}>
//         <div className={`toast `}>
//           <div>
//             <p className="toast-message" data-l10n-id={toastMessage}></p>
//           </div>
//         </div>
//       </div>
//     );
//   else
//     return <div></div>;
// };

// export default Toast;


class Toast extends React.Component {
  constructor(props) {
    super(props);
  }

  render() {
    if (this.props.displayToast) {
      return (
        <div className={`toast-container `}>
          <div className={`toast `}>
            {this.props.toastMessageText ? (<div>
              <p className="toast-message">{this.props.toastMessageText}</p>
            </div>):(<div>
              <p className="toast-message" data-l10n-id={this.props.toastMessage}></p>
            </div>)}
            </div>
        </div>
      );
    }
    else
      return null;
  }
}

Toast.propTypes = {
  toastMessage: PropTypes.string,
  displayToast: PropTypes.bool,
  toastMessageText: PropTypes.string,
};

Toast.defaultProps = {
  toastMessage: null,
  displayToast: false,
  toastMessageText: null,
};
export default Toast;