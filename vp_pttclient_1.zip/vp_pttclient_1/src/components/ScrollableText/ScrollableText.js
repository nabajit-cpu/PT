import React from "react";
import PropTypes from "prop-types";
import "./ScrollableText.less";

class ScrollableText extends React.Component {

  componentDidMount() {
    document.getElementById("abcd").focus();
  }

  renderText = (text) => {
    return text.map((item)=>{
      return (
        <div className="para" data-l10n-id={item}></div>
      );
    },this);
  }

  render(props) {
    return (
      <div
        tabIndex="0"
        className="wrapper"
        id="abcd"
      >
        {this.renderText(this.props.text)}
      </div>
    );
  }
}

ScrollableText.propTypes = {
  text: PropTypes.string.isRequired,
};

export default ScrollableText;
