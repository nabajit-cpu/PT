import React, { useCallback, useEffect } from "react";
import PropTypes from "prop-types";

import "./SoftKey.css";

const prefixCls = "jps-softkey";

const Button = (props) => {
  const { handleClick, icon, text } = props;

  function handleButtonClick(e) {
    e.preventDefault();
    handleClick();
  }

  // We want to avoid losing focus on the parent element
  function handleCheckFocus(e) {
    e.preventDefault();
    if (e.relatedTarget) {
      // Revert focus back to previous blurring element
      e.relatedTarget.focus();
    } else {
      // No previous focus target, blur instead
      e.currentTarget.blur();
    }
  }


    // <button
    //   className={`${prefixCls}-btn`}
    //   onClick={handleButtonClick}
    //   onFocus={handleCheckFocus}
    //   data-l10n-id={text}
    // >
    //   <img src="icon" width="24" height="24" alt="" ></img>
    //   {/* <span className={icon} /> */}
    //   {/* <img src={icon} /> */}
    // </button>
  if (icon == null)
    return (
      <button
        className={`${prefixCls}-btn`}
        onClick={handleButtonClick}
        onFocus={handleCheckFocus}
        data-l10n-id={text}
      ></button>
    );
  else
    return (
      <img
        src={icon}
        alt=""
        className={`${prefixCls}-img`}
        onClick={handleButtonClick}
        onFocus={handleCheckFocus}
      ></img>
    );
};

const SoftKey = React.memo((props) => {
  const {
    leftCallback,
    rightCallback,
    centerCallback,
    backCallback,
    leftText,
    rightText,
    centerText,
    centerIcon,
    backEnable,
  } = props;

  const handleKeyDown = useCallback(
    (e) => {
      switch (e.key) {
        case "SoftLeft":
        case "MozSoftLeft":
          leftCallback();
          break;
        case "SoftRight":
        case "MozSoftRight":
          rightCallback();
          break;
        case "Enter":
        case "Accept":
          // Action case press center key
          centerCallback();
          break;
        case "Backspace":
          if (backEnable) {
            e.preventDefault();
            e.stopPropagation();
            backCallback();
          }
          break;
        default:
          break;
      }
    },
    [leftCallback, rightCallback, centerCallback]
  );

  useEffect(() => {
    document.addEventListener("keydown", handleKeyDown);
    return () => document.removeEventListener("keydown", handleKeyDown);
  }, [handleKeyDown]);
  
  return (
    <div className={`${prefixCls} visible`}>
      <Button pos="left" text={leftText} handleClick={leftCallback} />
      <Button
        pos="center"
        text={centerText}
        icon={centerIcon}
        handleClick={centerCallback}
      />
      <Button pos="right" text={rightText} handleClick={rightCallback} />
    </div>
  );
});

SoftKey.propTypes = {
  leftText: PropTypes.string,
  centerText: PropTypes.string,
  rightText: PropTypes.string,
  centerIcon: PropTypes.string,
  leftCallback: PropTypes.func,
  centerCallback: PropTypes.func,
  rightCallback: PropTypes.func,
};

SoftKey.defaultProps = {
  leftText: "",
  centerText: "",
  rightText: "",
  centerIcon: null,
  backEnable: true,
  leftCallback: () => {},
  centerCallback: () => {},
  rightCallback: () => {},
};

export default SoftKey;
