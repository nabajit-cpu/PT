import React, { useCallback, useState, useEffect } from 'react';
import PropTypes from 'prop-types';
//import { SoftKeyConsumer } from '../SoftKey/withSoftKeyManager';
import './Slider.less';

const prefixCls = 'jps-slider';

const Slider = React.memo(props => {
  const {
    header,
    initValue,
    maxValue,
    minValue,
    stepSize,
    focusColor,
    forwardedRef,
    index,
    sliderId,
    trackLabel,
    onFocusChange,
    onValueChange,
    hideTrackLabel,
    //softKeyManager,
    //softKeyLeftText,
    //softKeyRightText,
  } = props;

  const [isFocused, setFocused] = useState(false);
  const [sliderValue, setSliderValue] = useState(initValue);

  const lineCls = `${prefixCls}-line`;
  const headerCls = `${prefixCls}-header`;
  const trackerCls = `${prefixCls}-tracker`;
  const sliderWrapperCls = `${prefixCls}-slider-wrapper`;

  useEffect(() => {
    if(sliderValue !== initValue){
      setSliderValue(initValue);
    }
  }, [initValue, sliderValue]);

  const handleFocusChange = useCallback(
    isNowFocused => {
      setFocused(isNowFocused);
      if (isNowFocused) {
        /*softKeyManager.setSoftKeyTexts({
          leftText: softKeyLeftText,
          rightText: softKeyRightText,
        });
        softKeyManager.setSoftKeyCallbacks({
          leftCallback: handleDecrementSlider,
          rightCallback: handleIncrementSlider,
        });*/
        onFocusChange(index);
      } else {
        //softKeyManager.unregisterSoftKeys();
      }
    },
    [index, onFocusChange]//, softKeyManager, softKeyLeftText, softKeyRightText]
  );

  //const handleDecrementSlider = () => {setSliderValue(prevVal => prevVal - 1);}

  //const handleIncrementSlider = () => setSliderValue(prevVal => prevVal + 1);

  //const handleSliderChange = event => setSliderValue(event.target.value);

  const handleKeyDown = (event) => {
    if (event.key === 'ArrowLeft'){
      //handleDecrementSlider();
      onValueChange(sliderId, sliderValue - 1);
    }
    else if(event.key === 'ArrowRight'){
      //handleIncrementSlider();
      onValueChange(sliderId, sliderValue + 1);
    }
  };

  return (
    <div
      tabIndex="0"
      className={prefixCls}
      style={{ backgroundColor: isFocused ? focusColor :  '#ffffff' }}
      ref={forwardedRef}
      onKeyDown={handleKeyDown}
      onFocus={() => handleFocusChange(true)}
      onBlur={() => handleFocusChange(false)}
    >
      <div className={lineCls}>
        <span className={headerCls} data-l10n-id={header}></span>
        {hideTrackLabel ? null : <span className={trackerCls}>{trackLabel ? trackLabel : `${sliderValue}/${maxValue}`}</span>}
      </div>

      <div className={sliderWrapperCls}>
        <input
          ref={forwardedRef}
          type="range"
          min={minValue}
          max={maxValue}
          step={stepSize}
          value={sliderValue}
          //onChange={handleSliderChange}
          style={{
            '--min': minValue,
            '--max': maxValue,
            '--val': sliderValue,
            '--slider-left-filler-color': isFocused ? '#ffffff' : focusColor,
            '--slider-thumb-border-color': isFocused? focusColor: '#ffffff',
          }}
        />
      </div>
    </div>
  );
});

Slider.propTypes = {
  onValueChange: PropTypes.func.isRequired,
  initValue: PropTypes.number.isRequired,
  maxValue: PropTypes.number.isRequired,
  minValue: PropTypes.number.isRequired,
  sliderId: PropTypes.string.isRequired,
  header: PropTypes.string.isRequired,
  //Id to get callback if multiple sliders are there in the same screen
  stepSize: PropTypes.number,
  trackLabel: PropTypes.string,
  focusColor: PropTypes.string,
  forwardedRef: PropTypes.oneOfType([
    PropTypes.func,
    PropTypes.shape({ current: PropTypes.any }),
  ]),
  index: PropTypes.number,
  onFocusChange: PropTypes.func,
  hideTrackLabel: PropTypes.bool,
  // For softkey
  //softKeyLeftText: PropTypes.string,
  //softKeyRightText: PropTypes.string,
};

Slider.defaultProps = {
  focusColor: "#0E4B9B",
  trackLabel: null,
  stepSize: 1,
  hideTrackLabel: false
  //softKeyLeftText: '',
  //softKeyRightText: '',
};

export default React.forwardRef((props, ref) => (
  /*<SoftKeyConsumer>
    {context => (
      <Slider softKeyManager={context} forwardedRef={ref} {...props} />
    )}
  </SoftKeyConsumer>*/
  <Slider forwardedRef={ref} {...props} />
));
