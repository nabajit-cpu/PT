import React from "react";
import Button from "../components/Button/Button";
import Header from "../components/Header/Header";
import { SoftKeyProvider } from "../components/SoftKey/SoftKeyProvider";
import ListView from "../views/ListView/ListView";
import "./OptionMenuRenderer.less";
import Icon from "../assets/icon.png";
import PropTypes from "prop-types";

/*

state = {
    showOptionMenu: false,
  };

  optionMenu = {
    menuItems: ["Test 1", "Test 2"],
  };

  rightSoftKeyText;
  centerSoftKeyText;
  leftSoftKeyText;

  handleRight = (ev, props) => {
    if (this.rightSoftKeyText === "Reset") {
      //  this.launchOptionsMenu();
      this.handleBack();
    } else {
      this.dismiss();
    }
  };


  launchOptionsMenu = () => {
    this.setState({
      showOptionMenu: true,
    });
  };

  updateState = (optionPressed) => {

    switch (optionPressed) {
      case 0:
        this.dismiss();
        break;
      case 1:
        this.dismiss();
        break;
      default:
        break;
    }
  };

  dismiss() {
    this.setState({
      showOptionMenu: false,
    });
  }


   render(props) {
    if (this.state.showOptionMenu) {
      this.rightSoftKeyText = "";
      this.leftSoftKeyText = "";
      this.centerSoftKeyText = "SELECT";
    } else {
      this.rightSoftKeyText = "Reset";
      this.leftSoftKeyText = "";
      this.centerSoftKeyText = "SELECT";
    }

          <OptionMenuRenderer
            {...this.optionMenu}
            updateFunction={this.updateState}
            boolOptionMenu={this.state.showOptionMenu}
            focusColor="#0E4B9B"
            headerColor="#03007F"
            headerTextColor="#FFFFFF"
          />


  Refer APNSettings.js
*/

class OptionMenuRenderer extends React.Component {
  constructor(props) {
    super(props);
  }

  render(props) {
    if (this.props.boolOptionMenu) {
      return (
        <div className="OpMenu">
          <Header
            text="Options"
            backgroundColor={this.props.headerColor}
            headerTextColor={this.props.headerTextColor}
          />
          <SoftKeyProvider
            icon={Icon}
            backgroundColor={this.props.softKeyColor}
            left=""
            right=""
            center="SELECT"
          >
            <div className="op-content">
              <ListView>
                {/* {listItemValues(this.props)} */}
                {this.props.menuItems.map((menu, i) => (
                  <Button
                    key={i}
                    text={menu}
                    onClick={() => this.props.updateFunction(i)}
                    focusColor={this.props.focusColor}
                  />
                ))}
              </ListView>
            </div>
          </SoftKeyProvider>
        </div>
      );
    } else {
      return <div></div>;
    }
  }
}

OptionMenuRenderer.propTypes = {
  headerColor: PropTypes.string,
  headerTextColor: PropTypes.string,
  focusColor: PropTypes.string,
  softKeyColor: PropTypes.string,
  updateFunction: PropTypes.func,
};

export default OptionMenuRenderer;
