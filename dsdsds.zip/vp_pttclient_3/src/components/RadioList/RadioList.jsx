import React, { Component, Fragment } from "react";
import RadioListItem from "./RadioListItem";
import { PropTypes } from "prop-types";
import Logger from "../../utils/logger";
const TAG="RadioList:: "

class RadioList extends Component {
  static getDerivedStateFromProps(props, state) {
    props.listObject.map((objectData, index) => {
      if (objectData.isChecked) state.currentChecked = index;
    });

    return state;
  }

  state = {
    currentFocused: 0,
    currentChecked: -1,
  };

  componentDidMount() {
    document.addEventListener("keydown", this.handleEvent);
  }
  componentWillUnmount() {
    document.removeEventListener("keydown", this.handleEvent);
  }

  handleEvent = (e, id) => {
    let currentFocus = this.state.currentFocused;

    if (e.key === "ArrowDown") {
      if (this.state.currentFocused === this.props.listObject.length - 1) {
        currentFocus = 0;
      } else {
        currentFocus++;
      }
      this.setState({ currentFocused: currentFocus });
    }

    if (e.key === "ArrowUp") {
      if (this.state.currentFocused === 0) {
        currentFocus = this.props.listObject.length - 1;
      } else {
        currentFocus--;
      }
      this.setState({ currentFocused: currentFocus });
    }

    if (e.key === "Accept" || e.key === "Enter") {
      if (this.state.currentChecked !== currentFocus) {
        let checkedlist = this.props.listObject;
        checkedlist.forEach((element, index) => {
          element.isChecked = currentFocus === index ? true : false;
        });
        this.props["onModeChange"](checkedlist);
        this.setState({ currentChecked: currentFocus });
      }
    }
  };

  render() {
    let reactRadioObject = this.props.listObject.map((objectData, index) => (
      <RadioListItem
        key={index}
        label={objectData.label}
        isChecked={index === this.state.currentChecked}
        isFocused={index === this.state.currentFocused}
        id={index}
        labelText={objectData.labelText}
      />
    ));
    return <div onKeyDown={this.handleEvent}>{reactRadioObject}</div>;
  }
}

RadioList.defaultProps = {
  listObject: [
    { label: "enable", isChecked: false, isFocused: true, labelText: null },
    { label: "disable", isChecked: true, isFocused: false, labelText: null },
  ],
  onModeChange: (checkedlist) => {
    Logger.info(TAG , "Not Implemented");
  },
  
};

RadioList.propTypes = {
  listObject: PropTypes.array,
  onModeChange: PropTypes.func,
  onCancel: PropTypes.func
};
export default RadioList;
