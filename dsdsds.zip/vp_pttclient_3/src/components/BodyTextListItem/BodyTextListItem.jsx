import React from 'react';
import { useFocus } from '../../hooks';
import PropTypes from "prop-types";


import './BodyTextListItem.less';

const prefixCls = 'jps-btl';


const BodyTextListItem = React.memo((props) => {
    const {
        header,
        body,
        focusColor,
        forwardedRef,
        index,
        onFocusChange,
        className,
        l10nId
    } = props;

    const handleFocusChange = isNowFocused => {
        if (isNowFocused) {
            onFocusChange(index);
        }
    }

    const isFocused = useFocus(forwardedRef, handleFocusChange, false);

    const itemCls = prefixCls;
    const headerCls = `${prefixCls}-header`;
    const bodyCls = `${prefixCls}-body ${body ? '' : 'hidden'}`;

    return (
        <div
            tabIndex={0}
            className={className || itemCls}

            ref={forwardedRef}
        >
            <span className={headerCls} data-l10n-id={l10nId}>{header}</span>
            <label className={bodyCls}> {body}</label>
        </div>
    );
});

BodyTextListItem.propTypes = {
    header: PropTypes.string,
    body: PropTypes.string,
    focusColor: PropTypes.string,
    // Refocus on tab change
    forwardedRef: PropTypes.any,
    onFocusChange: PropTypes.func,
    index: PropTypes.number,
    className: PropTypes.string,
    l10nId: PropTypes.string
};

BodyTextListItem.defaultProps = {
    onFocusChange: () => { },
    focusColor: "#0E4B9B",
    l10nId: null
};

export default React.forwardRef((props, ref) => (
    <BodyTextListItem forwardedRef={ref} {...props} />
));