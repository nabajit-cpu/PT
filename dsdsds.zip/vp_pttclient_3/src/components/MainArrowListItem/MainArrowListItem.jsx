import React from "react";
import PropTypes from "prop-types";
import { useFocus } from "../../hooks/useFocus";
import rightArrowIcon from "../../assets/right_arrow.svg";
import "./MainArrowListItem.css";

const prefixCls = "jps-mal";

const MainArrowListItem = React.memo((props) => {
  const {
    primary,
    secondary,
    focusColor,
    forwardedRef,
    toPath,
    index,
    onFocusChange,
    itemdisabled,
    HeaderIcon,
    l10Attribute,
    isShowArrow
  } = props;

  const handleFocusChange = (isNowFocused) => {
    if (isNowFocused) {
      onFocusChange(index);
    }
  };

  const isFocused = useFocus(forwardedRef, handleFocusChange, false);

  const iconCls = `${prefixCls}-icon-${isFocused ? "focused" : "unfocused"}`;
  const primaryCls = `${prefixCls}-primary`;
  const secondaryCls = `${prefixCls}-secondary`;
  const headericonCls = `${prefixCls}-header-icon-${
    isFocused ? "focused" : "unfocused"
  }`;
  const headerIconComponentClass = `${prefixCls}-header-icon-component-${
    isFocused ? "focused" : "unfocused"
  }`;

  return (
    <div
      tabIndex="0"
      className={prefixCls}
      ref={forwardedRef}
      style={{backgroundColor: isFocused ? focusColor : "#FFFFFF",}}
      id={toPath}
      itemdisabled={itemdisabled}
    >
      { HeaderIcon ?
        <div className={headericonCls}>
          <HeaderIcon className={headerIconComponentClass}/>
        </div>
      : null }
      <div className="jps-mal-line">
        <span
          data-l10n-id={primary}
          className={
            itemdisabled === "enabled"
              ? primaryCls
              : isFocused
              ? `${primaryCls}-disabled-focused`
              : `${primaryCls}-disabled`
          }
        >
          {primary}
        </span>
        {secondary ?
          <label
            data-l10n-id={secondary}
            data-l10n-args={l10Attribute !== null ? l10Attribute.toString() : null}
            className={
              itemdisabled === "enabled"
                ? secondaryCls
                : isFocused
                ? `${secondaryCls}-disabled-focused`
                : `${secondaryCls}-disabled`
            }
          />
        : null}
      </div>
      {isShowArrow ?
        <div className={iconCls}>
          <img src={rightArrowIcon} alt="" />
        </div>
      : null }
    </div>
  );
});

MainArrowListItem.propTypes = {
  primary: PropTypes.string,
  secondary: PropTypes.string,
  focusColor: PropTypes.string,
  forwardedRef: PropTypes.oneOfType([
    PropTypes.func,
    PropTypes.shape({ current: PropTypes.any }),
    //PropTypes.shape({ current: PropTypes.oneOfType }),
  ]),
  index: PropTypes.number,
  onFocusChange: PropTypes.func,
  toPath: PropTypes.string,
  itemdisabled: PropTypes.string,
  l10Attribute: PropTypes.string,
  isShowArrow: PropTypes.bool
};

MainArrowListItem.defaultProps = {
  primary: null,
  secondary: null,
  focusColor: "#0E4B9B",
  itemdisabled: "enabled",
  l10Attribute: null,
  isShowArrow: true,
};

export default React.forwardRef((props, ref) => (
  <MainArrowListItem forwardedRef={ref} {...props} />
));
