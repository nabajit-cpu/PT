import React from "react";

import { SoftKeyProvider } from "../SoftKey/SoftKeyProvider";

import "./Dialog.less";
import Header from "../Header/Header";
import ReactDOM from "react-dom";
import PropTypes from "prop-types";

/*
How to use

state = {
  showDialog: false,
};

this.setState({ showDialog: true });

Add this to tag parallel to softkeyprovider
<Dialog
            showDialog={this.state.showDialog}
            leftText="No"
            rightText="Yes"
            bodyText="This is a Dialogue box"
            leftCall={this.onCancel}
            rightCall={this.onCancel}
            headerText="Header"
          />
Refer NetworkDetails.js
*/

class Dialog extends React.Component {

  componentDidMount() {
    if(this.props.showDialog){
      let element = document.getElementById("contentdialog");
      element.setAttribute('tabindex', '0')
      element.focus();
    }
    document.addEventListener("keydown", this.handleKeyDown);
  }

  handleKeyDown = (e) => {
    let element = document.getElementById("contentdialog");
    switch (e.key) {
      case "ArrowUp":
      case "ArrowDown":
        ReactDOM.findDOMNode(element).scrollIntoView({behaviour: "smooth",block: "start", inline: "nearest"});
        ReactDOM.findDOMNode(element).focus()
        break;
      default:
        break;
      
    }
  }

  componentWillUnmount(){
    document.removeEventListener("keydown", this.handleKeyDown)
  }
  
  render() {
    if (this.props.showDialog) {
      return (
        <div className="root-dialog">
          <Header text={this.props.headerText} />
          <SoftKeyProvider
            left={this.props.leftText}
            right={this.props.rightText}
            center={this.props.centerText}
            rightCallback={this.props.rightCall}
            leftCallback={this.props.leftCall}
            centerCallback={this.props.centerCall}
            backCallback={this.props.backCall}
          >
            <div id = "contentdialog" > {this.props.bodyText} </div>
          </SoftKeyProvider>
        </div>
      );
    } else {
      return null;
    }
  }
}

Dialog.propTypes = {
  bodyText: PropTypes.string,
  leftText: PropTypes.string,
  rightText: PropTypes.string,
  centerText: PropTypes.string,
  headerText: PropTypes.string,
  //softKeyColor:PropTypes.string,
  leftCall: PropTypes.func,
  rightCall: PropTypes.func,
  centerCall: PropTypes.func,
  backCall: PropTypes.func,
  // updateFunction: PropTypes.func,
};

export default Dialog;