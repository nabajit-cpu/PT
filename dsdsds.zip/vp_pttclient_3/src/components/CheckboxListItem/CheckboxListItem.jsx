import React, { useEffect, useState, useCallback } from 'react';
import PropTypes from 'prop-types';
import { SoftKeyConsumer } from '../SoftKey/withSoftKeyManager';
import './CheckboxListItem.less';

const prefixCls = 'jps-cbl';

const CheckboxListItem = React.memo(props => {
  const {
    primary,
    secondary,
    initCheckboxVal,
    onInputChange,
    checkboxSide,
    focusColor,
    onFocusChange,
    onChecked,
    index,
    forwardedRef,
    softKeyManager,
    softKeyCheckedText,
    softKeyUncheckedText,
    softKeyCheckedIcon,
    softKeyUncheckedIcon,
    isEnabled,
    toPath,
  } = props;

  // Managed vs self-managed radio buttons
  const [isChecked, setChecked] = useState(initCheckboxVal);
  const [isFocused, setFocused] = useState(false);

  const itemCls = prefixCls;
  const boxCls = `${prefixCls}-box`;
  const lineCls = `${prefixCls}-line ${
    checkboxSide === 'left' ? 'right' : 'left'
  }`;
  const primaryCls = `${prefixCls}-primary`;
  const secondaryCls = `${prefixCls}-secondary ${secondary ? '' : 'hidden'}`;
  const inputCls = `${boxCls}-input-${isFocused ? 'focused' : 'unfocused'}`;

  useEffect(() => {
    const centerText = isChecked ? softKeyCheckedText : softKeyUncheckedText;
    const centerIcon = isChecked ? softKeyCheckedIcon : softKeyUncheckedIcon;
    if (isFocused) {
      if (centerIcon != null) {
        softKeyManager.setCenterIcon(centerIcon);
      } else {
        softKeyManager.setCenterText(centerText);
      }
    }
  }, [
    isFocused,
    isChecked,
    softKeyManager,
    softKeyCheckedText,
    softKeyUncheckedText,
    softKeyCheckedIcon,
    softKeyUncheckedIcon,
  ]);

  const handleFocusChange = useCallback(
    isNowFocused => {
      setFocused(isNowFocused);
      if (isNowFocused) {
        const centerText = isChecked
          ? softKeyCheckedText
          : softKeyUncheckedText;
        const centerIcon = isChecked
          ? softKeyCheckedIcon
          : softKeyUncheckedIcon;
        if (centerIcon != null) {
          softKeyManager.setCenterIcon(centerIcon);
        } else {
          softKeyManager.setSoftKeyTexts({ centerText });
        }
        // softKeyManager.setSoftKeyCallbacks({
        //   centerCallback: handleInvertCheck,
        // });
        onFocusChange(index);
      } else {
        softKeyManager.unregisterSoftKeys();
      }
    },
    [
      index,
      onFocusChange,
      isChecked,
      softKeyCheckedText,
      softKeyUncheckedText,
      softKeyCheckedIcon,
      softKeyUncheckedIcon,
      softKeyManager,
    ]
  );

  const checkbox = (
    <div className={boxCls}>
      <input
        className={inputCls}
        tabIndex="-1"
        type="checkbox"
        checked={onChecked}
        onChange={() => {}}
        id={toPath}
      //  onFocus={handleCheckFocus}
       // onClick={handleInputChange}
      />
    </div>
  );

  return (
    <div
      tabIndex="0"
      className={itemCls}
      style={{ backgroundColor: isFocused ? focusColor : "#FFFFFF" }}
      ref={forwardedRef}
      onFocus={() => handleFocusChange(true)}
      onBlur={() => handleFocusChange(false)}
      id={toPath}
      itemdisabled={isEnabled? "enabled":"disabled"}
    >
      {checkboxSide === 'left' ? checkbox : null}
      <div className={lineCls}>
        <span className={primaryCls} style={{color: !isEnabled ? "#808080" : ""}} data-l10n-id={primary}></span>
        {secondary ? <label className={secondaryCls} data-l10n-id={secondary}></label> : null}
      </div>
      {checkboxSide === 'right' ? checkbox : null}
    </div>
  );
});

CheckboxListItem.propTypes = {
  primary: PropTypes.string.isRequired,
  secondary: PropTypes.string,
  // Used for unmanaged checkboxes
  initCheckboxVal: PropTypes.bool.isRequired,
  onInputChange: PropTypes.func,
  // For direct management over the checkbox value
  isChecked: PropTypes.bool,
  onChecked: PropTypes.bool,
  checkboxSide: PropTypes.oneOf(['left', 'right']).isRequired,
  focusColor: PropTypes.string,
  // For ListView navigation
  onFocusChange: PropTypes.func,
  index: PropTypes.number,
  forwardedRef: PropTypes.oneOfType([
    PropTypes.func,
    PropTypes.shape({ current: PropTypes.any }),
  ]),
  // For softkey
  softKeyCheckedText: PropTypes.string,
  softKeyUncheckedText: PropTypes.string,
  softKeyCheckedIcon: PropTypes.string,
  softKeyUncheckedIcon: PropTypes.string,
  toPath: PropTypes.string,
};

CheckboxListItem.defaultProps = {
  secondary: null,
  isChecked: null,
  isEnabled: true,
  focusColor: "#0E4B9B",
  softKeyCheckedText: 'Deselect',
  softKeyUncheckedText: 'Select',
  softKeyCheckedIcon: null,
  softKeyUncheckedIcon: null
};

export default React.forwardRef((props, ref) => (
  <SoftKeyConsumer>
    {context => (
      <CheckboxListItem
        softKeyManager={context}
        forwardedRef={ref}
        {...props}
      />
    )}
  </SoftKeyConsumer>
));
