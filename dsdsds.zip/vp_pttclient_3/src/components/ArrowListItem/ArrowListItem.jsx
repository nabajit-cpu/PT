import React from "react";
import PropTypes from "prop-types";
import { useFocus } from "../../hooks/useFocus";
import rightArrowIcon from "../../assets/right_arrow.svg";
import "./ArrowListItem.css";

const prefixCls = "jps-al";

const ArrowListItem = React.memo((props) => {
  const {
    primary,
    secondary,
    focusColor,
    forwardedRef,
    toPath,
    index,
    onFocusChange,
    isShowArrow,
    isSecondaryOnRight,
    itemdisabled,
    HeaderIcon,
    isShowIcon,
    secondaryText,
    primaryText,
    tertiaryText,
    tertiary,
    l10Attribute,
    primaryTextwrap
  } = props;

  const handleFocusChange = (isNowFocused) => {
    if (isNowFocused) {
      onFocusChange(index);
    }
  };

  const isFocused = useFocus(forwardedRef, handleFocusChange, false);

  const itemCls = prefixCls;
  const iconCls = `${prefixCls}-icon-${isFocused ? "focused" : "unfocused"}`;
  const lineCls = `${prefixCls}-line`;
  const primaryCls = `${prefixCls}-primary`;
  const secondaryCls = `${prefixCls}-secondary${
    isSecondaryOnRight ? "-right": ""
  }`;
  const tertiaryCls = `${prefixCls}-tertiary`;
  const headericonCls = `${prefixCls}-header-icon-${
    isFocused ? "focused" : "unfocused"
  }`;
  const headerIconComponentClass = `${prefixCls}-header-icon-component-${
    isFocused ? "focused" : "unfocused"
  }`;
  const renderedArrowIcon = <img src={rightArrowIcon} alt="" />;
  const renderedHeaderIcon = typeof(HeaderIcon)=='object'?
    <HeaderIcon className={headerIconComponentClass}/> : <img src={HeaderIcon} alt="" />;

  return (
    <div
      tabIndex="0"
      className={itemCls}
      ref={forwardedRef}
      style={{backgroundColor: isFocused ? focusColor : "#FFFFFF",}}
      id={toPath}
      itemdisabled={itemdisabled}
    >
      {isShowIcon ?
        <div className={headericonCls}>
          { renderedHeaderIcon}
        </div> 
      : null}
      <div className={lineCls}>
        {primaryText?(
          <span
            className={
              itemdisabled === "enabled"
                ? primaryCls
                : isFocused
                ? `${primaryCls}-disabled-focused`
                : `${primaryCls}-disabled`
            }
            style={{whiteSpace: primaryTextwrap ? "normal" : "nowrap"}}
          >
            {primaryText} 
          </span>
        ):(
          <span
          data-l10n-id={primary}
          className={
            itemdisabled === "enabled"
              ? primaryCls
              : isFocused
              ? `${primaryCls}-disabled-focused`
              : `${primaryCls}-disabled`
          }
          style={{whiteSpace: primaryTextwrap ? "normal" : "nowrap"}}
        >
          {primary}
        </span>
        )
      }
      {(secondary||secondaryText) ? (
        secondaryText ? ( 
          isSecondaryOnRight? (
            <div className="jps-al-right-container">
              <label
                className={
                  itemdisabled === "enabled"
                    ? secondaryCls
                    : isFocused
                    ? `${secondaryCls}-disabled-focused`
                    : `${secondaryCls}-disabled`
                }
              >
                {secondaryText}
              </label>
              <div className={iconCls}>{renderedArrowIcon}</div>
            </div>
          ):(
            <label
              className={
                itemdisabled === "enabled"
                  ? secondaryCls
                  : isFocused
                  ? `${secondaryCls}-disabled-focused`
                  : `${secondaryCls}-disabled`
              }
            >
              {secondaryText}
            </label>)
        ):(
          isSecondaryOnRight ? (
            <div className="jps-al-right-container">
              <label
                data-l10n-id={secondary}
                data-l10n-args={l10Attribute !== null ? l10Attribute : null}
                className={
                  itemdisabled === "enabled"
                    ? secondaryCls
                    : isFocused
                    ? `${secondaryCls}-disabled-focused`
                    : `${secondaryCls}-disabled`
                }
              />
              <div className={iconCls}>{renderedArrowIcon}</div>
            </div>
          ):(
            <label
              data-l10n-id={secondary}
              data-l10n-args={l10Attribute !== null ? l10Attribute : null}
              className={
                itemdisabled === "enabled"
                  ? secondaryCls
                  : isFocused
                  ? `${secondaryCls}-disabled-focused`
                  : `${secondaryCls}-disabled`
              }
            />
          )
        )
      ): null
      }
      {(tertiary || tertiaryText) ? (
        tertiaryText ?
          (<label
            className={
              itemdisabled === "enabled"
                ? tertiaryCls
                : isFocused
                  ? `${tertiaryCls}-disabled-focused`
                  : `${tertiaryCls}-disabled`
            }
          >
            {tertiaryText}
          </label>) :
          (<label
            data-l10n-id={tertiary}
            className={
              itemdisabled === "enabled"
                ? tertiaryCls
                : isFocused
                  ? `${tertiaryCls}-disabled-focused`
                  : `${tertiaryCls}-disabled`
            }
          >
          </label>)
      ) : null
      }
      </div>
      {isShowArrow && !isSecondaryOnRight ? 
        <div className={iconCls}>{renderedArrowIcon}</div>
      :null}
    </div>
  );
});

ArrowListItem.propTypes = {
  primary: PropTypes.string,
  secondary: PropTypes.string,
  focusColor: PropTypes.string,
  forwardedRef: PropTypes.oneOfType([
    PropTypes.func,
    PropTypes.shape({ current: PropTypes.any }),
    //PropTypes.shape({ current: PropTypes.oneOfType }),
  ]),
  index: PropTypes.number,
  onFocusChange: PropTypes.func,
  isShowArrow: PropTypes.bool,
  isSecondaryOnRight: PropTypes.bool,
  toPath: PropTypes.string,
  itemdisabled: PropTypes.string,
  isShowIcon: PropTypes.bool,
  secondaryText: PropTypes.string,
  primaryText: PropTypes.string,
  tertiaryText: PropTypes.string,
  tertiary: PropTypes.string,
  l10Attribute: PropTypes.string,
  primaryTextwrap: PropTypes.bool,
};

ArrowListItem.defaultProps = {
  primary: null,
  secondary: null,
  secondaryText: null,
  primaryText: null,
  isShowArrow: true,
  isSecondaryOnRight: false,
  focusColor: "#0E4B9B",
  itemdisabled: "enabled",
  isShowIcon: false,
  tertiaryText: null,
  tertiary: null,
  l10Attribute:null,
  primaryTextwrap:false,
};

export default React.forwardRef((props, ref) => (
  <ArrowListItem forwardedRef={ref} {...props} />
));
