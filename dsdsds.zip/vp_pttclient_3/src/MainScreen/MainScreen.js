import React from "react";
import "./MainScreen.css";
import { ReactComponent as SplashIcon } from "./icon-large.svg";

class MainScreen extends React.Component {
  componentDidMount() {
    window.setTimeout(() => {
      require("../App/App");
      window.componentManager.startComponent("/app", {}, this.props.identifier);
      const statusbarcolor = "rgba(255, 49, 49, 1)";
      let meta = document.createElement("meta");
      meta.name = "theme-color";
      meta.content = statusbarcolor;
      document.getElementsByTagName("head")[0].appendChild(meta);
    }, 400);
  }

  render() {
    return (
      <div className="splash-wrapper">
        <SplashIcon />
      </div>
    );
  }
}

export default window.componentManager.registerComponent("/Home", <MainScreen />);
