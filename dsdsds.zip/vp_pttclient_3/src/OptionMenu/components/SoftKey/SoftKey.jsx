import React, { useCallback, useEffect } from 'react';
import PropTypes from 'prop-types';
import icon2 from '../../assets/icon.png'

import './SoftKey.css';

const prefixCls = 'jps-softkey';

const Button = props => {
  const { handleClick, icon, text } = props;

  const handleButtonClick = e => {
    e.preventDefault();
    handleClick();
  };

  // We want to avoid losing focus on the parent element
  const handleCheckFocus = e => {
    e.preventDefault();
    if (e.relatedTarget) {
      // Revert focus back to previous blurring element
      e.relatedTarget.focus();
    } else {
      // No previous focus target, blur instead
      e.currentTarget.blur();
    }
  };

  return (
    <button
      className={`${prefixCls}-btn`}
      onClick={handleButtonClick}
      onFocus={handleCheckFocus}
      
    >
      <img src={icon}/>
      <span className={icon} />
      {text}
    </button>
  );
};

const SoftKey = React.memo(props => {
  const {
    leftCallback,
    rightCallback,
    centerCallback,
    backCallback,
    leftText,
    rightText,
    centerText,
    centerIcon,
    backEnable,
    backgroundColor
  } = props;

  const handleKeyDown = useCallback(
    e => {
      switch (e.key) {
        case 'SoftLeft':
          leftCallback();
          break;
        case 'SoftRight':
          rightCallback();
          break;
        case 'Enter':
          // Action case press center key
          centerCallback();
          break;
        case 'Backspace':
          if(backEnable){
            e.preventDefault();
            e.stopPropagation();
            backCallback();
          }
          break;
        default:
          break;
      }
    },
    [leftCallback, rightCallback, centerCallback]
  );

  useEffect(() => {
    document.addEventListener('keydown', handleKeyDown);
    return () => document.removeEventListener('keydown', handleKeyDown);
  }, [handleKeyDown]);

  if(backEnable){
    return null;
  }
  else{
  return (
    <div className={`${prefixCls} visible`} style={{background:backgroundColor}}>
      <Button pos="left" text={leftText} handleClick={leftCallback} iconSrc={icon2}/>
      <Button
        
        pos="center"
        text={centerText}
        icon={centerIcon}
        handleClick={centerCallback}
      />
      <Button pos="right" text={rightText} handleClick={rightCallback} />
    </div>
  );
  }
});

SoftKey.propTypes = {
  leftText: PropTypes.string,
  centerText: PropTypes.string,
  rightText: PropTypes.string,
  centerIcon: PropTypes.string,
  leftCallback: PropTypes.func,
  centerCallback: PropTypes.func,
  rightCallback: PropTypes.func,
  backgroundColor: PropTypes.string
};

SoftKey.defaultProps = {
  leftText: '',
  centerText: '',
  rightText: '',
  centerIcon: null,
  leftCallback: () => {},
  centerCallback: () => {},
  rightCallback: () => {},
  backgroundColor: ""
};

export default SoftKey;
