import React from 'react';
import PropTypes from 'prop-types';
import './Header.less';

const prefixCls = 'jps-header';
const Header = React.memo(
  props => {
    const {
      text,
      backgroundColor,
      headerTextColor
    } = props;

    return (
      <header className={prefixCls} style={{ background: backgroundColor, color: headerTextColor }}>
        <h1 className="opHeader">{text}</h1>
      </header>
    );
  }
);

Header.propTypes = {
  text: PropTypes.string.isRequired,
  backgroundColor: PropTypes.string,
};

Header.defaultProps = {
  backgroundColor: "grey",
  headerTextColor: "#FFFFFF"
};

export default Header;
