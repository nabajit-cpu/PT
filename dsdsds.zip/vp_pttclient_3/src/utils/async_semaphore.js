
class AsyncSemaphore{
    
 

  // Do not call '_init' and '_execute' directly from outside of AsyncSemaphore

  constructor() {
      // Please don't modify these value directly from outside of AsyncSemaphore
      this.pendingTasks = [];
      this.semaphore = 0;
    };
    _execute() {
      var task,
        context;
      if (this.semaphore <= 0) {
        while (this.pendingTasks.length > 0) {
          task = this.pendingTasks.shift();
          context = task.context || this;
          if (task && task.callback && typeof task.callback === 'function') {
            task.callback.call(context, task.args);
          }
        }
      }
    };
    v(num) {
      if (!num) {
        num = 1;
      }
      this.semaphore += num;
    };
    p() {
      this.semaphore -= 1;
      if (this.semaphore < 0) {
        this.semaphore = 0;
      }
      this._execute();
    };
    wait(callback, context, args) {
      this.pendingTasks.push({
        callback: callback,
        context: context,
        args: args
      });
      this._execute();
    };
    getValue() {
      return this.semaphore;
    };
    getTasksLength() {
      return this.pendingTasks.length;
    }
  };

  export default AsyncSemaphore;

