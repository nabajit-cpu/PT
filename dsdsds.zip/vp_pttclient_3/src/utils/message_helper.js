import { encode, decode } from "notepack.io";
import { MessageType, ChannelType } from "./channel_message_Type";
import Logger from "./logger";
const TAG = "MessageHelper :: ";

let MessageHelper = {
  unpackMessage: function (payload) {
    Logger.log(TAG, "MessageHelper unpackMessage ===>");
    return decode(payload);
  },

  createConnectionMessage: function (senderId) {
    Logger.log(TAG, "MessageHelper createConnectionMessage ===>");
    return encode([ChannelType.GROUP, MessageType.CONNECTION, senderId]);
  },

  createAckStartMessage: function (senderId, receiverId, channelType, duration) {
    Logger.log(TAG, "MessageHelper createAckStartMessage ===>");
    return encode([channelType, MessageType.START_TALKING, senderId, receiverId, duration]);
  },

  createAudioMessage: function (senderId, receiverId, channelType, payload, length) {
    Logger.log(TAG, "MessageHelper createAudioMessage ===>");
    return encode([channelType, MessageType.AUDIO, senderId, receiverId, payload]);
  },

  createAckStopMessage: function (senderId, receiverId, channelType) {
    Logger.log(TAG, "MessageHelper createAckStopMessage ===>");
    return encode([channelType, MessageType.STOP_TALKING, senderId, receiverId]);
  },

  createAckReceiveMessage: function (senderId, receiverId, channelType, ackIds) {
    Logger.log(TAG, "MessageHelper createAckReceiveMessage ===>");
    return encode([channelType, MessageType.MESSAGE_DELIVERED, senderId, receiverId, ackIds]);
  },

  createAckReadMessage: function (sendTo, type, id) {
    Logger.log(TAG, "MessageHelper createAckReadMessage ===>");
    return encode([type, MessageType.MESSAGE_READ, 1, sendTo, id]);
  },

  createTextMessage: function (channelType, fromID, toID, message) {
    Logger.log(TAG, "MessageHelper createTextMessage ===>");
    return encode([channelType, MessageType.TEXT, fromID, toID, message]);
  },

  createStatusMessage: function (senderId, status) {
    Logger.log(TAG, "MessageHelper createStatusMessage ===>");
    return encode([ChannelType.GROUP, MessageType.STATUS, senderId, 0, status]);
  },

  createSubscribeMessage: function (senderId, groupId) {
    Logger.log(TAG, "MessageHelper createSubscribeMessage ===>");
    return encode([ChannelType.GROUP, MessageType.CHANNEL_ADDED_USER, senderId, groupId]);
  },

  createUnsubscribeMessage: function (senderId, groupId) {
    Logger.log(TAG, "MessageHelper createUnsubscribeMessage ===>");
    return encode([ChannelType.GROUP, MessageType.CHANNEL_REMOVED_USER, senderId, groupId]);
  },
};
export default MessageHelper;
