/* globals indexedDB */
/**
 * This file defines an asynchronous version of the localStorage API, backed by
 * an IndexedDB database.  It creates a global asyncStorage object that has
 * methods like the localStorage object.
 *
 * To store a value use setItem:
 *
 *   asyncStorage.setItem('key', 'value');
 *
 * If you want confirmation that the value has been stored, pass a callback
 * function as the third argument:
 *
 *  asyncStorage.setItem('key', 'newvalue', function() {
 *    Logger.debug(TAG , 'new value stored');
 *  });
 *
 * To read a value, call getItem(), but note that you must supply a callback
 * function that the value will be passed to asynchronously:
 *
 *  asyncStorage.getItem('key', function(value) {
 *    Logger.debug(TAG , 'The value of key is:', value);
 *  });
 *
 * Note that unlike localStorage, asyncStorage does not allow you to store and
 * retrieve values by setting and querying properties directly. You cannot just
 * write asyncStorage.key; you have to explicitly call setItem() or getItem().
 *
 * removeItem(), clear(), length(), and key() are like the same-named methods of
 * localStorage, but, like getItem() and setItem() they take a callback
 * argument.
 *
 * The asynchronous nature of getItem() makes it tricky to retrieve multiple
 * values. But unlike localStorage, asyncStorage does not require the values you
 * store to be strings.  So if you need to save multiple values and want to
 * retrieve them together, in a single asynchronous operation, just group the
 * values into a single object. The properties of this object may not include
 * DOM elements, but they may include things like Blobs and typed arrays.
 *
 * Unit tests are in apps/gallery/test/unit/asyncStorage_test.js
 */
import Logger from "./logger";
const TAG= "AsyncStorage:: "
let asyncStorage = {
 

  DBNAME : 'asyncStorage',
  DBVERSION : 1,
 STORENAME : 'keyvaluepairs',
  db : null,

  withDatabase: function(f) {
    if (this.db) {
      f();
    } else {
      var openreq = indexedDB.open(this.DBNAME, this.DBVERSION);
      openreq.onerror = function withStoreOnError() {
        Logger.error(TAG, 'asyncStorage: can\'t open database:',
            openreq.error.name);
      };
      openreq.onupgradeneeded = function withStoreOnUpgradeNeeded() {
        // First time setup: create an empty object store
        openreq.result.createObjectStore(this.STORENAME);
      };
      openreq.onsuccess = function withStoreOnSuccess() {
        this.db = openreq.result;
        f();
      };
    }
  },

  withStore: function(type, callback, oncomplete) {
    this.withDatabase(function() {
      var transaction = this.db.transaction(this.STORENAME, type);
      if (oncomplete) {
        transaction.oncomplete = oncomplete;
      }
      callback(transaction.objectStore(this.STORENAME));
    });
  },

  getItem: function(key, callback) {
    var req;
    this.withStore('readonly', function getItemBody(store) {
      req = store.get(key);
      req.onerror = function getItemOnError() {
        Logger.error(TAG, 'Error in asyncStorage.getItem(): ', req.error.name);
      };
    }, function onComplete() {
      var value = req.result;
      if (value === undefined) {
        value = null;
      }
      callback(value);
    });
  },

  setItem: function(key, value, callback) {
    this.withStore('readwrite', function setItemBody(store) {
      var req = store.put(value, key);
      req.onerror = function setItemOnError() {
        Logger.error(TAG, 'Error in asyncStorage.setItem(): ', req.error.name);
      };
    }, callback);
  },

  removeItem: function(key, callback) {
    this.withStore('readwrite', function removeItemBody(store) {
      var req = store.delete(key);
      req.onerror = function removeItemOnError() {
        Logger.error(TAG, 'Error in asyncStorage.removeItem(): ', req.error.name);
      };
    }, callback);
  },

  clear:function(callback) {
    this.withStore('readwrite', function clearBody(store) {
      var req = store.clear();
      req.onerror = function clearOnError() {
        Logger.error(TAG, 'Error in asyncStorage.clear(): ', req.error.name);
      };
    }, callback);
  },

  length: function (callback) {
    var req;
    this.withStore('readonly', function lengthBody(store) {
      req = store.count();
      req.onerror = function lengthOnError() {
        Logger.error(TAG, 'Error in asyncStorage.length(): ', req.error.name);
      };
    }, function onComplete() {
      callback(req.result);
    });
  },

  key: function(n, callback) {
    if (n < 0) {
      callback(null);
      return;
    }

    var req;
    this.withStore('readonly', function keyBody(store) {
      var advanced = false;
      req = store.openCursor();
      req.onsuccess = function keyOnSuccess() {
        var cursor = req.result;
        if (!cursor) {
          // this means there weren't enough keys
          return;
        }
        if (n === 0 || advanced) {
          // Either 1) we have the first key, return it if that's what they
          // wanted, or 2) we've got the nth key.
          return;
        }

        // Otherwise, ask the cursor to skip ahead n records
        advanced = true;
        cursor.advance(n);
      };
      req.onerror = function keyOnError() {
        Logger.error(TAG, 'Error in asyncStorage.key(): ', req.error.name);
      };
    }, function onComplete() {
      var cursor = req.result;
      callback(cursor ? cursor.key : null);
    });
  },


};
export default asyncStorage; 

