import React, { Component } from "react";
import loadable from "@loadable/component";

import Header from "../components/Header/Header";
import ListView from "../views/ListView/ListView";
import { SoftKeyProvider } from "../components/SoftKey/SoftKeyProvider";
import Logger from "../utils/logger";
import "./App.less";
import TextInput from "../components/TextInput/TextInput";
import Toast from "../components/Toast/Toast";
import PushToTalk from "../utils/push_to_talk";
import Connection from "../utils/connection";

const JoinGroup = loadable(() =>
  import(/* webpackPrefetch: true */ "../screens/PTT/Join/JoinGroup")
);

const TAG = "App.js:: ";

class App extends Component {
  constructor(props) {
    super(props);
    if (props.isRecreated) {
      this.state.s_tabIndex = props.bundle.s_tabIndex;
      this.state.l_index = props.bundle.l_index;
      this.state.isRecreated = props.isRecreated;
    }

    this.userID = null;
    this.company = null;
    this.serverURL = "wss://router-lite.voiceping.info";
    this.enterPressed = this.enterPressed.bind(this);
    this.onListIndexChange = this.onListIndexChange.bind(this);
  }
  state = {
    l_index: 0,
    l1_index: 0,
    s_tabIndex: 0,
    isRecreated: false,
    headertext: "",
    toastMessage: "",
    displayToast: false,
  };

  loadDependency() {
    JoinGroup.preload();
  }

  componentDidMount() {
    this.loadDependency();
    this.init();
    if (this.props.isRecreated) {
    }
  }

  init = () => {
    this.serverURL = "wss://router-lite.voiceping.info";
    window.localStorage.removeItem("groupType");
  };

  itempressed = (navigatingparam) => {};

  onTextEntered = (event) => {
    //Logger.log("text entered", event.target.id, event.target.value);
    switch (event.target.id) {
      case "userId":
        this.userID = event.target.value;
        // this.setState({ userID: event.target.value });
        break;
      case "company":
        this.company = event.target.value;
        // this.setState({ company: event.target.value });
        break;
      case "serverUrl":
        this.serverURL = event.target.value;
        // this.setState({ serverURL: event.target.value });
        break;
    }
  };

  disabledPressed = (navparam) => {
    // eslint-disable-next-line default-case
  };

  onListIndexChange(listIndex) {
    if (listIndex !== this.state.l_index) {
      this.setState({ l_index: listIndex });
    }
  }

  enterPressed() {
    Logger.log(TAG, "Enter Pressed");
    if (this.userID && this.company) {
      PushToTalk.connect(
        this.userID,
        this.company,
        () => {
          console.log("Connected");
          window.componentManager.registerComponent("/joinGroup", <JoinGroup />);
          window.componentManager.startComponent(
            "/joinGroup",
            { userId: this.userID, company: this.company, serverURL: this.serverURL },
            this.props.identifier,
            this.state,
            this.props
          );
        },
        this.serverURL
      );
    } else {
      this.setState({
        displayToast: true,
        toastMessage: "input-error",
      });
      setTimeout(() => {
        this.setState({ displayToast: false });
      }, 3000);
    }
  }

  render() {
    Logger.log(TAG, "App.js render()");
    return (
      <div className="App">
        <Header text="ptt" />
        <SoftKeyProvider backEnable={false} center="Enter" centerCallback={this.enterPressed}>
          <div className="content">
            <ListView
              callback={this.itempressed}
              currentIndex={this.state.l_index}
              onChangeIndex={this.onListIndexChange}
              isRecreated={this.state.isRecreated}
              disabledCallback={this.disabledPressed}
            >
              <TextInput
                label="user-id"
                id="userId"
                placeholder="User id"
                onChange={this.onTextEntered}
                initValue=""
              />
              <TextInput
                label="company"
                id="company"
                placeholder="Company"
                onChange={this.onTextEntered}
                initValue=""
              />
              <TextInput
                label="serverURL"
                id="serverUrl"
                placeholder="Server URL"
                onChange={this.onTextEntered}
                initValue={this.serverURL}
              />
              <div>You can only talk to other users in the same company</div>
            </ListView>
          </div>
        </SoftKeyProvider>
        <Toast toastMessage={this.state.toastMessage} displayToast={this.state.displayToast} />
      </div>
    );
  }
}

export default window.componentManager.registerComponent("/app", <App />);
