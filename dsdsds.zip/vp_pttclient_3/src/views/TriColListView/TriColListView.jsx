import React, { useState, useEffect, useCallback } from 'react';
import './TriColListView.less';
import PropTypes from "prop-types";
import ScrollListView from '../ScrollingListView/ScrollListView';
import ListView from '../ListView/ListView';

const prefixCls = 'jps-tricol-view';



const TriColListView = React.memo((props) => {
    const {
        onChangeIndex,
        focusColor,
        col1Children,
        col2Children,
        col3Children,
        onCol1ChangeIndex,
        onCol2ChangeIndex,
        onCol3ChangeIndex,
        selectedCol1Index,
        selectedCol2Index,
        selectedCol3Index
    } = props;

    const [activeTab, setActiveTab] = useState(0);
    const [isTransitionDone, setTransitionDone] = useState(true);

    const handleChangeIndex = tabIndex => {
        // NOTE: Ensure you set state for tab transition first.
        // Otherwise you will face strange race condition bugs.
        setTransitionDone(false);
        setActiveTab(tabIndex);
        if (onChangeIndex) {
            onChangeIndex(tabIndex);
        }
    };


    const handleKeyDown = useCallback(
        e => {
            let index = activeTab;
            switch (e.key) {
                case 'ArrowLeft':
                    index = index - 1 >= 0 ? index - 1 : 2;
                    setActiveTab(index);
                    break;
                case 'ArrowRight':
                    index = index + 1 < 3 ? index + 1 : 0;
                    setActiveTab(index);
                default:
                    break;
            }
        },
        [activeTab, setActiveTab]
    );

    useEffect(
        () => {
            document.addEventListener('keydown', handleKeyDown);
            return () => document.removeEventListener('keydown', handleKeyDown);
        },
        [handleKeyDown]
    );

    const renderChildren = (children) => {
        return React.Children.map(children, (child, i) => {
            return React.cloneElement(child, {
                isActive: activeTab === i && isTransitionDone,
                onFocusChange: handleChangeIndex,
                focusClass: "defaultFocusCls"
            });
        });
    };

    return (
        <div className={prefixCls}>
            <div className={prefixCls + "-content"}>
                <ScrollListView
                    isActive={activeTab === 0}
                    className={col3Children.length > 0 ? "col" : "colFor2ItemList"}
                    initialSelectedIndex={selectedCol1Index}
                    onChangeIndex={(index) => onCol1ChangeIndex(index)}
                >
                    {renderChildren(col1Children)}
                </ScrollListView>
                <ScrollListView
                    isActive={activeTab === 1}
                    className={col3Children.length > 0 ? "col" : "colFor2ItemList"}
                    initialSelectedIndex={selectedCol2Index}
                    onChangeIndex={(index) => onCol2ChangeIndex(index)}
                >
                    {renderChildren(col2Children)}
                </ScrollListView>

                {col3Children.length > 0
                    ? <ScrollListView
                        isActive={activeTab === 2}
                        className="col"
                        initialSelectedIndex={selectedCol3Index}
                        onChangeIndex={(index) => onCol3ChangeIndex(index)}
                    >
                        {renderChildren(col3Children)}
                    </ScrollListView>
                    : ""
                }
            </div>
        </div>
    );
}
);

TriColListView.propTypes = {
    onChangeIndex: PropTypes.func,
    col1Children: PropTypes.array.isRequired,
    col2Children: PropTypes.array.isRequired,
    col3Children: PropTypes.array.isRequired,
    onCol1ChangeIndex: PropTypes.func,
    onCol2ChangeIndex: PropTypes.func,
    onCol3ChangeIndex: PropTypes.func,
    selectedCol1Index: PropTypes.number,
    selectedCol2Index: PropTypes.number,
    selectedCol3Index: PropTypes.number,
    focusColor: PropTypes.string,
};

TriColListView.defaultProps = {
    onFocusChange: () => { },
    focusColor: "#0E4B9B",
};


export default TriColListView;