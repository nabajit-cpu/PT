import React, { Component } from "react";
import { PropTypes } from "prop-types";

import { SoftKeyProvider } from "../../../components/SoftKey/SoftKeyProvider";
import Header from "../../../components/Header/Header";
import RadioButtonItem from "../../../components/RadioButtonItem/RadioButtonItem";
import ListView from "../../../views/ListView/ListView";
import Logger from "../../../utils/logger";

const TAG = "GroupType:: ";
class GroupType extends Component {
  state = {
    showDialog: false,
    isButtonDisabled: false,
    isEnabled: this.props.isGroupEnabled,
    isYesClicked: this.props.isGroupEnabled,
  };

  setMode = (id) => {
    console.log(id);
    switch (id) {
      case "group":
        this.setState({ isEnabled: true });

        break;
      case "private":
        this.setState({ isEnabled: false });
        break;
    }
    window.localStorage.setItem("groupType", this.state.isEnabled);
    window.componentManager.finish(this.props.identifier);
  };

  setLockScreenAlertValue = (isEnabled) => {};

  handleBack = () => {
    window.componentManager.finish(this.props.identifier);
  };

  render() {
    return (
      <div className="App">
        <Header text="channelType" />
        <SoftKeyProvider left="cancel" center="ok" backCallback={this.handleBack}>
          <div>
            <ListView callback={this.setMode}>
              <RadioButtonItem
                primary="group"
                isChecked={this.state.isEnabled}
                isEnabled={!this.state.isButtonDisabled}
                id="group"
              />
              <RadioButtonItem
                primary="private"
                isChecked={!this.state.isEnabled}
                isEnabled={!this.state.isButtonDisabled}
                id="private"
              />
            </ListView>
          </div>
        </SoftKeyProvider>
      </div>
    );
  }
}

GroupType.props = {
  isGroupEnabled: PropTypes.bool,
};

export default GroupType;
