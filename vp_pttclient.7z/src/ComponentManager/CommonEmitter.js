let EmitterHandler = function() {
    this.eventMap = new Map();   
 }
 
 EmitterHandler.prototype.addHandler = function (eventUri) {
     this.eventMap.set(eventUri,{});
 }
 
 EmitterHandler.prototype.emitEvent = function (eventUri){
 let eventObj = this.eventMap.get(eventUri);
 this.eventMap.delete(eventUri);
 console.log("emitEvent : ", eventObj);
 return eventObj;
 }
 
 EmitterHandler.prototype.recieveEvent = function(eventUri,args){
         this.eventMap.set(eventUri,{"arguments":args});
         console.log("recieve event : ", args);
 }
 
 EmitterHandler.prototype.hasAnyEvent = function(eventUri){
     if(this.eventMap.has(eventUri)){
         return true;
     }
     return false;
 }
 
 export default EmitterHandler;