import React from "react";
import PropTypes from "prop-types";
import { useFocus } from "../../hooks/useFocus";
import "./ImageItem.css";

const prefixCls = "jps-image-item";

const ImageItem = React.memo((props) => {
  const { forwardedRef, onFocusChange, index, imageSrc, id } = props;

  const handleFocusChange = (isNowFocused) => {
    if (isNowFocused) {
      if (index === 0) {
        onFocusChange(index + 1); // to not give focus on single image view
      } else {
        onFocusChange(index);
      }
    }
  };

  const isFocused = useFocus(forwardedRef, handleFocusChange, false);

  const itemCls = prefixCls;
  const renderImage = <img src={imageSrc} />;
  return (
    <div
      tabIndex="0"
      className={itemCls}
      ref={forwardedRef}
      style={{
        backgroundColor: "#FFFFFF",
      }}
    >
      {renderImage}
    </div>
  );
});

ImageItem.propTypes = {
  forwardedRef: PropTypes.oneOfType([
    PropTypes.func,
    PropTypes.shape({ current: PropTypes.any }),
  ]),
  onFocusChange: PropTypes.func,
  index: PropTypes.number,
  imageSrc: PropTypes.string.isRequired,
  id: PropTypes.string,
};

ImageItem.defaultProps = {
  imageSrc: "",
  id: "image",
};

export default React.forwardRef((props, ref) => (
  <ImageItem forwardedRef={ref} {...props} />
));
