import React from "react";
import PropTypes from "prop-types";
import { useFocus } from "../../hooks/useFocus";
import "./ButtonItem.css";

const prefixCls = "jps-bi";

const ButtonItem = React.memo((props) => {
  const {
    primary,
    focusColor,
    forwardedRef,
    toPath,
    index,
    onFocusChange,
    itemdisabled,
  } = props;

  const handleFocusChange = (isNowFocused) => {
    if (isNowFocused) {
      onFocusChange(index);
    }
  };

  const isFocused = useFocus(forwardedRef, handleFocusChange, false);

  const itemCls = prefixCls;
  const iconCls = `${prefixCls}-icon-${isFocused ? "focused" : "unfocused"}`;
  const lineCls = `${prefixCls}-line`;
  const primaryCls = `${prefixCls}-primary`;
  return (
    <div
      tabIndex="0"
      className={itemCls}
      ref={forwardedRef}
      style={{
        backgroundColor:
          itemdisabled === "enabled"
            ? isFocused
              ? focusColor
              : "#FFFFFF"
            : "#676F7A",
      }}
      id={toPath}
      itemdisabled={itemdisabled}
    >
      
      <div className={lineCls}>
        <span
          className={itemdisabled === "enabled" ? primaryCls : `${primaryCls}-disabled`}
        >
          {primary}
        </span>
      </div>
    </div>
  );
});

ButtonItem.propTypes = {
  primary: PropTypes.string.isRequired,
  focusColor: PropTypes.string,
  forwardedRef: PropTypes.oneOfType([
    PropTypes.func,
    PropTypes.shape({ current: PropTypes.any }),
    //PropTypes.shape({ current: PropTypes.oneOfType }),
  ]),
  index: PropTypes.number,
  onFocusChange: PropTypes.func,
  toPath: PropTypes.string,
  itemdisabled: PropTypes.string,
};

ButtonItem.defaultProps = {
  focusColor: "#0E4B9B",
  itemdisabled: "enabled",
};

export default React.forwardRef((props, ref) => (
  <ButtonItem forwardedRef={ref} {...props} />
));
