import React from 'react';
import PropTypes from 'prop-types';
import { useFocus } from '../../hooks';
import { requireOneOf } from '../../utils/requireOneOf';

import './IconListItem.less';

const prefixCls = 'jps-il';

const IconListItem = React.memo(
  props => {
    const {
      primary,
      secondary,
      icon,
      iconSrc,
      focusColor,
      forwardedRef,
      index,
      onFocusChange,
      itemdisabled,
      iconSizefixed,
      primaryText,
      secondaryText,
      toPath,
      isSecondaryOnRight,
    } = props;

    const handleFocusChange = isNowFocused => {
      if (isNowFocused) {
        onFocusChange(index);
      }
    }

    const isFocused = useFocus(forwardedRef, handleFocusChange, false);

  const itemCls = prefixCls;
  const iconCls = `${prefixCls}-icon-${
    isFocused
      ? iconSizefixed
        ? "size-fixed-focused"
        : "focused"
      : iconSizefixed
      ? "size-fixed-unfocused"
      : "unfocused"
  }`;

    const lineCls = `${prefixCls}-line`;
    const primaryCls = `${prefixCls}-primary`;
    const secondaryCls = `${prefixCls}-secondary${isSecondaryOnRight ? "-right": ""}`;

    const renderedIcon = iconSrc === null ?
        null :
        <img src={iconSrc} alt="" />;

    return (
     
      <div
        tabIndex="0"
        className={itemCls}
        ref={forwardedRef}
        id={toPath}
        style={{ backgroundColor: isFocused ? focusColor : "#FFFFFF" }}
      	itemdisabled={itemdisabled}
      >
        <div className={iconCls}>
          {renderedIcon}
        </div>
        <div className={lineCls}>
          {primaryText?
            <span className={primaryCls} >{primaryText}</span> :
            <span className={primaryCls} data-l10n-id={primary}></span>
          }
          { isSecondaryOnRight ? null :
            secondary ?            
              <label className={secondaryCls} data-l10n-id={secondary}></label>:
            secondaryText ?
              <label className={secondaryCls}> {secondaryText}</label> :
            null
          }
        </div>
        { ! isSecondaryOnRight ? null :
            secondary ?            
              <label className={secondaryCls} data-l10n-id={secondary}></label>:
            secondaryText ?
              <label className={secondaryCls}> {secondaryText}</label> :
            null
          }
      </div>
    );
  }
);

const requireOneIcon = requireOneOf({
  icon: PropTypes.string,
  iconSrc: PropTypes.string
});

IconListItem.propTypes = {
  primary: PropTypes.string,
  secondary: PropTypes.string,
  primaryText: PropTypes.string,
  secondaryText: PropTypes.string,
  icon: requireOneIcon,
  iconSrc: requireOneIcon,
  focusColor: PropTypes.string,
  forwardedRef: PropTypes.oneOfType([
    PropTypes.func,
    PropTypes.any,
  ]),
  index: PropTypes.number,
  onFocusChange: PropTypes.func,
  itemdisabled: PropTypes.string,
  iconSizefixed: PropTypes.bool,
  toPath: PropTypes.string,
  isSecondaryOnRight: PropTypes.bool,
};

IconListItem.defaultProps = {
  primary: null,
  primaryText: null,
  secondary: null,
  secondaryText: null,
  icon: null,
  iconSrc: null,
  focusColor: "#0E4B9B",
  itemdisabled: "enabled",
  iconSizefixed: false,
  isSecondaryOnRight: false,
};

export default React.forwardRef((props, ref) => (
  <IconListItem forwardedRef={ref} {...props} />
));
