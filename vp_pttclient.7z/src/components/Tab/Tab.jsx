import React from 'react';
import PropTypes from 'prop-types';


import './Tab.less';

const prefixCls = 'tab';

const Tab = React.memo((props) => {

 // computed: {
    const actPrefixCls = `${prefixCls}${props.isActive ? '-active' : '-inactive'}`;
    

    /*activeIndicator: ({isActive}) => {
      return isActive ? 'circle' : 'none';
    }*/
 // },

  

    return (
      <div
        onClick={props.handleClick}
        className={actPrefixCls}
        //style={{ '--tab-underline-color': props.focusColor }}
        ref={props.forwardedRef}
      >
        <div className={`${actPrefixCls}-label`} data-l10n-id={props.label}></div>
        {/*<div className={`${props.activeIndicator}`}/>*/}
      </div>
    );
  
});

Tab.propTypes= {
  index: PropTypes.number,
  label: PropTypes.string,
  onTabChange: PropTypes.func,
  isActive: PropTypes.bool,
  //focusColor: PropTypes.string,
  forwardedRef: PropTypes.oneOfType([
    PropTypes.func,
    PropTypes.shape({ current: PropTypes.any }),
  ]),
}

Tab.defaultProps= {
  index: 0,
  label: null,
  onTabChange: () => {},
  isActive: false
}


export default React.forwardRef((props, ref) => (
  <Tab forwardedRef={ref} {...props} />
));
