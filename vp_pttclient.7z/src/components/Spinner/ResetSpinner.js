import React from "react";
import PropTypes from "prop-types";

import "./Spinner.less";

class ResetSpinner extends React.Component{

  constructor(props){
    super(props);
  }

  render() {
    return(
    <div>
      <div className= "spinner-text" style={{"textAlign": "center", "color": "#707070"}} data-l10n-id="reset-phone-info">
      </div>

      <div className="spinner largespinner">
        <div className="bar1 largebar"/>
        <div className="bar2 largebar"/>
        <div className="bar3 largebar"/>
        <div className="bar4 largebar"/>
        <div className="bar5 largebar"/>
        <div className="bar6 largebar"/>
        <div className="bar7 largebar"/>
        <div className="bar8 largebar"/>
      </div>
    </div>
  )}
};



export default ResetSpinner;
