import React from "react";
import PropTypes from "prop-types";
import "./Paragraph.less";
class Paragraph extends React.Component {
  constructor(props) {
    super(props);
  }

  render(props) {
    if (this.props.isBig) {
      return (
        <p
          className="para1"
          style={{
            "font-size": window.navigator.largeTextEnabled?"1.1rem":"0.875rem",
            "margin-left": "0.53rem",
            "margin-right": "0.2rem",
            "fontStyle":"normal"
          }}
          data-l10n-id={this.props.text}>
        </p>
      );
    } else {
      return (
        <p className={this.props.isItalic ? "paraitalic" : "para1"}
        data-l10n-id={this.props.text}>
        </p>
      );
    }
  }
}
Paragraph.propTypes = {
  text: PropTypes.string.isRequired,
  isItalic: PropTypes.bool,
  isBig: PropTypes.bool,
};
Paragraph.defaultProps = {
  isItalic: false,
  isBig: false,
};

export default Paragraph;
