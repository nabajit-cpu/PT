import React from "react";

import { SoftKeyProvider } from "../SoftKey/SoftKeyProvider";

import "./TimePickerDialog.less";
import Header from "../Header/Header";
import PropTypes from "prop-types";
import TriColListView from "../../views/TriColListView/TriColListView";
import BodyTextListItem from "../BodyTextListItem/BodyTextListItem";
import Logger from "../../utils/logger"
const TAG="TimePickerDialog:: "


class TimePickerDialog extends React.Component {
    constructor(props) {
        super(props);

        Logger.debug(TAG , "selectedhours " + this.props.initialTime.getHours());


        let selectedHour = -1;
        let selectedPeriod = -1;
        let selectedMinute = this.props.initialTime.getMinutes();
        if (selectedMinute / 10 < 1) {
            selectedMinute = "0" + selectedMinute;
        }
        let periods = [];
        let hours = [];
        if (this.props.isHour12Format) {
            selectedHour = this.formatAMPM(this.props.initialTime).hour;
            selectedPeriod = this.formatAMPM(this.props.initialTime).period;
            periods = ["AM", "PM"];
            for (let i = 0; i < 12; i++) {
                let j = i + 1;
                if (j / 10 < 1) {
                    j = "0" + j;
                }
                hours.push(j);
            }
        } else {
            selectedHour = this.props.initialTime.getHours();
            selectedHour = selectedHour < 10 ? '0' + selectedHour : selectedHour;
            for (let i = 0; i <= 23; i++) {
                if (i / 10 < 1) {
                    i = "0" + i;
                }
                hours.push(i);
            }
        }

        let minutes = [];
        for (let i = 0; i <= 59; i++) {

            if (i / 10 < 1) {
                i = "0" + i;
            }
            minutes.push(i);
        }



        this.state = {
            hours: hours,
            minutes: minutes,
            periods: periods,
            selectedHour: selectedHour,
            selectedMinute: selectedMinute,
            selectedPeriod: selectedPeriod,
        };

    }

    setHour = (index) => {
        this.setState({
            selectedHour: this.state.hours[index]
        });
    }

    setMinute = (index) => {
        this.setState({
            selectedMinute: this.state.minutes[index]
        });
    }

    setPeriod = (index) => {
        this.setState({
            selectedPeriod: this.state.periods[index]
        });
    }

    formatAMPM = (date) => {
        var hours = date.getHours();
        var minutes = date.getMinutes();
        var periods = hours >= 12 ? 'PM' : 'AM';
        hours = hours % 12;
        hours = hours ? hours : 12; // the hour '0' should be '12'
        hours = hours < 10 ? '0' + hours : hours;
        minutes = minutes < 10 ? '0' + minutes : minutes;
        //var strTime = hours + ':' + minutes + ' ' + periods;
        return {
            hour: hours,
            minute: minutes,
            period: periods
        };
    }

    okSelected = () => {
        this.props.centerCall(this.calcSelectedTime());
    }


    componentWillReceiveProps(props) {
        let selectedPeriod = "";
        let selectedHour = -1;
        let hours = [];
        let periods = [];
        if (this.props.isHour12Format) {
            selectedHour = this.formatAMPM(this.props.initialTime).hour;
            selectedPeriod = this.formatAMPM(this.props.initialTime).period;
            periods = ["AM", "PM"];
            for (let i = 0; i < 12; i++) {
                let j = i + 1;
                if (j / 10 < 1) {
                    j = "0" + j;
                }
                hours.push(j);
            }
        } else {
            selectedHour = this.props.initialTime.getHours();
            selectedHour = selectedHour < 10 ? '0' + selectedHour : selectedHour;
            for (let i = 0; i <= 23; i++) {
                if (i / 10 < 1) {
                    i = "0" + i;
                }
                hours.push(i);
            }
        }
        this.setState({
            hours: hours,
            periods: periods,
            selectedHour: selectedHour,
            selectedPeriod: selectedPeriod,
        });
    }



    calcSelectedTime = () => {
        let selectedDateTime = "";
        if (this.props.isHour12Format) {
            const am_pm_to_hours = this.am_pm_to_hours(this.state.selectedHour + ":" +
                this.state.selectedMinute +
                " " + this.state.selectedPeriod);


            selectedDateTime = new Date(this.props.initialTime.getFullYear(),
                this.props.initialTime.getMonth(),
                this.props.initialTime.getDate(),
                am_pm_to_hours.hour,
                am_pm_to_hours.min, 0, 0);

        }
        else {
            selectedDateTime = new Date(this.props.initialTime.getFullYear(),
                this.props.initialTime.getMonth(),
                this.props.initialTime.getDate(),
                this.state.selectedHour,
                this.state.selectedMinute, 0, 0)
        }
        Logger.debug(TAG , "selectedDateTime :" + selectedDateTime);
        return {
            hour: this.state.selectedHour,
            minute: this.state.selectedMinute,
            period: this.state.selectedPeriod,
            selectedDateTime: selectedDateTime
        };
    }

    am_pm_to_hours = (time) => {
        var PM = time.match('PM') ? true : false

        time = time.split(':')
        let min = ""
        let hour = "";

        if (PM) {
            if (time[0] == 12) {
                hour = 12;
            }
            else {
                hour = 12 + parseInt(time[0], 10)
            }
            min = time[1].replace('PM', '')

        } else {
            if (time[0] == 12) {
                hour = 0;
            }
            else {
                hour = time[0]
            }
            min = time[1].replace('AM', '')
        }

        return {
            hour: hour,
            min: min
        };
    }
    render() {
        if (this.props.showDialog) {
            return (
                <div className="root-dialog">
                    <div className="Dialog">
                        <Header text={this.props.headerText} />
                        <SoftKeyProvider
                            left={this.props.leftText}
                            center={this.props.centerText}
                            centerCallback={this.okSelected}
                            leftCallback={this.props.leftCall}
                        >

                            <div className="contentdialog">
                                <TriColListView
                                    col1Children={this.state.hours.map((item) => (<BodyTextListItem header={item.toString()} />))}
                                    col2Children={this.state.minutes.map((item) => (<BodyTextListItem header={item.toString()} />))}
                                    col3Children={this.state.periods.map((item) => (<BodyTextListItem header={item.toString()} />))}
                                    onCol1ChangeIndex={(index) => this.setHour(index)}
                                    onCol2ChangeIndex={(index) => this.setMinute(index)}
                                    onCol3ChangeIndex={(index) => this.setPeriod(index)}
                                    selectedCol1Index={this.state.hours.indexOf(this.state.selectedHour)}
                                    selectedCol2Index={this.props.initialTime.getMinutes()}
                                    selectedCol3Index={this.state.periods.indexOf(this.state.selectedPeriod)}

                                />
                            </div>
                        </SoftKeyProvider>
                    </div>
                </div>
            );
        } else {
            return <div></div>;
        }
    }
}

TimePickerDialog.propTypes = {
    leftText: PropTypes.string,
    centerText: PropTypes.string,
    leftCall: PropTypes.func,
    centerCall: PropTypes.func,
    headerText: PropTypes.string,
    initialTime: PropTypes.instanceOf(Date).isRequired,
    isHour12Format: PropTypes.bool
    // updateFunction: PropTypes.func,
};

export default TimePickerDialog;
