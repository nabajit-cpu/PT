import React, { Component } from 'react';
import './CreatePasscode.less';
import PropTypes from "prop-types";
import Logger from "../../utils/logger";

const TAG = "CreatePasscode:: "
class CreatePasscode extends Component {
    constructor(props) {
        super(props);
        this.qwertyKeyMapping = {
            'w': '1', 'e': '2', 'r': '3', 's': '4', 'd': '5',
            'f': '6', 'z': '7', 'x': '8', 'c': '9', ',': '0'
        };
        this.state = {
            values: [],
            isfocusedRow1: true,
            isfocusedRow2: false
        }
    }
    
    componentDidMount(){
        document.addEventListener('keydown', this.handleEvent);
    }

    translateKey = (key) => {
        Logger.debug(TAG , "qwertyKeyMapping "+ this.qwertyKeyMapping[key]);
        return this.qwertyKeyMapping[key] || key;
    }


    handleEvent = (e, id) => {
        Logger.debug(TAG , "handle event id " + e.key);
        let dialogOpened = this.props.isDialogOpen
        if (dialogOpened) {
            e.preventDefault();
            e.stopPropagation();
        } else {

            //var keyCode = e.key;
            var keyCode = this.translateKey(e.key);
            Logger.debug(TAG , "handle keyCode " + e.key);
            if (!(keyCode >= '0' && keyCode <= '9') && keyCode != 'Backspace') {
                e.preventDefault();
                return false;
            } else {
                if (keyCode == 'Backspace') {
                    if (!this.props.isShowConfirmDialog){
                        this.setState((state, props) => {
                            let newValues = [...state.values]
                            newValues.pop()
                            return {
                                values: newValues
                            }
                        });
                        this._updatePassCodeUI();
                        e.stopPropagation();
                        if (this.state.values.length === 0) {
                            document.removeEventListener('keydown', this.handleEvent);
                            this.props.onExit();
                        }
                        e.preventDefault();
                    }
                } else {
                    this.state.values.push(keyCode);
                    if (this.state.values.length < 9) {
                        this._updatePassCodeUI();
                        if (this.state.values.length === 8) {
                            this.passcodeLogic();
                        }
                    }
                }
            }

        }

    }

    _updatePassCodeUI = () => {
        //   this.posscodeInput.classList.add('highlight');
        //  this.posscodeConfirmInput.classList.remove('highlight');
        for (var i = 0; i < 8; i++) {
            if (i < this.state.values.length) {
                if (i < 3) {
                    this.setState({
                        isfocusedRow1: true,
                        isfocusedRow2: false,
                    });
                } else if ((i <= 7) && (i >= 3)) {
                    this.setState({
                        isfocusedRow1: false,
                        isfocusedRow2: true,
                    });
                }
                document.getElementById("pin-" + (i + 1)).dataset.dot = true;
            } else {
                delete document.getElementById("pin-" + (i + 1)).dataset.dot;
            }

        }
    }

    passcodeLogic = () => {

        let newValues = [...this.state.values];
        this.props.onPinSet(newValues);
        let match = true
        for (let i = 0; i < 4; i++) {
            if (newValues[i] != newValues[i + 4]) {
                match = false;
                break;
            }
        }

        if (!match) {
            this.setState((state, props) => {
                let newValues = [...state.values]
                for (let i = 0; i < 8; i++) {
                    newValues.pop();
                }
                this.setState({
                    isfocusedRow1: true,
                    isfocusedRow2: false,
                });

                return {
                    values: newValues
                }
            });
        }
        this._updatePassCodeUI();
        return

    }

    componentWillUnmount(){
        document.removeEventListener('keydown', this.handleEvent);
    }

    inputElementRenderMethod = (i) => {
        return <span className="create-passcode-digit"
            name={"pin-" + (i + 1)}
            id={"pin-" + (i + 1)}
            key={"pin-" + (i + 1)}
        />;
    }

    render() {
        let inputs1 = [...Array(4).keys()].map(function (i) {
            if (i === 0) {
                return (
                    <div>
                        {this.state.isfocusedRow1 ? <span className="create-passcode-span-focus" data-l10n-id="create-a-passcode"></span>
                            : <span className="create-passcode-span-unfocus" data-l10n-id="create-a-passcode"></span>}
                        {this.inputElementRenderMethod(i)}
                    </div>);
            } else {
                return this.inputElementRenderMethod(i);
            }

        }.bind(this)
        );

        let inputs2 = [...Array(4).keys()].map(function (j) {
            j = j + 4;
            if (j === 4) {
                return (
                    <div >
                        {this.state.isfocusedRow2 ? <span className="create-passcode-span-focus" ddata-l10n-id="confirm-the-passcode"></span>
                            : <span className="create-passcode-span-unfocus" data-l10n-id="confirm-the-passcode"></span>}
                        {this.inputElementRenderMethod(j)}
                    </div>);
            } else {
                return this.inputElementRenderMethod(j);
            }

        }.bind(this)
        );


        return (
            <div className="create-passcode-container">
                {this.state.isfocusedRow1 ? <div className="create-passcode-focus">  {inputs1}
                </div> : <div className="create-passcode-unfocus">  {inputs1}
                    </div>}

                {this.state.isfocusedRow2 ? <div className="create-passcode-focus">  {inputs2}
                </div> : <div className="create-passcode-unfocus">  {inputs2}
                    </div>}

            </div>
        );
    }
};

CreatePasscode.propTypes = {
    isDialogOpen: PropTypes.bool,
    isShowConfirmDialog: PropTypes.bool,
    // updateFunction: PropTypes.func,
};

CreatePasscode.defaultProps = {
    isDialogOpen: false,
    isShowConfirmDialog: false,
}
export default CreatePasscode;


