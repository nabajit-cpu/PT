import React, { Component } from "react";
import css from "./RadioListItem.module.less";
import { PropTypes } from "prop-types";

class RadioListItem extends Component {
  render() {
    let checkedClassName;
    if (this.props.isChecked) {
      if (this.props.isFocused) {
        checkedClassName = css.focusedcheckedcustomradio;
      } else {
        checkedClassName = css.checkedcustomradio;
      }
    } else {
      if (this.props.isFocused) {
        checkedClassName = css.focusedcheckedcustomradiohidden;
      } else {
        checkedClassName = css.checkedcustomradiohidden;
      }
    }

    return (
      <div
        className={
          this.props.isFocused ? css.focusedselectablediv : css.selectablediv
        }
      >
        {this.props.labelText?(
                  <div
                  className={
                    this.props.isFocused ? css.focuseditemlabel : css.itemlabel
                  } style={{"font-size": window.navigator.largeTextEnabled ? "1.313rem" : "1.0625rem",
                  "width": window.navigator.largeTextEnabled ? "75vw":"90vw"}}>
                    {this.props.labelText}
                </div>
        ):(
        <div
        className={
          this.props.isFocused ? css.focuseditemlabel : css.itemlabel
        }
        data-l10n-id= {this.props.label}
        style={{"font-size": window.navigator.largeTextEnabled ? "1.313rem" : "1.0625rem",
        "width": window.navigator.largeTextEnabled ? "75vw":"90vw"}}>
      </div>
        )}

        <div
          className={
            this.props.isFocused ? css.focusedcustomradio : css.customradio
          }
        >
          <div
            className={
              this.props.isFocused
                ? css.focusedinnercustomradio
                : css.innercustomradio
            }
          >
            <div className={checkedClassName}></div>
          </div>
        </div>
      </div>
    );
  }
}

RadioListItem.propTypes = {
  label: PropTypes.string.isRequired,
  isFocused: PropTypes.bool,
  isChecked: PropTypes.bool,
  labelText: PropTypes.string
};

RadioListItem.defaultProps = {
  label: "Dummy-label",
  isFocused: false,
  isChecked: false,
  labelText: null
};

export default RadioListItem;
