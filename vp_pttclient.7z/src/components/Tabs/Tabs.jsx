import React, { useCallback, useEffect, useRef, useState } from "react";
import PropTypes from "prop-types";
import "./Tabs.less";
import ReactDOM from "react-dom";
const prefixCls = "jps-tabs";

const Tabs = React.memo((props) => {
  const { onChangeIndex, children, current_Tab, isRecreated, isDialogOpen } = props;

  const childRefs = [];
  const [activeChild, setActiveChild] = useState(current_Tab);

  const handleTabChange = useCallback(
    (childIndex) => {
       setActiveChild(childIndex);
      // (childRefs[childIndex].current).scrollIntoView({
      //   behavior: "auto",
      //   block: "start",
      //   inline: "center",
      // });
      onChangeIndex(childIndex);
    },
    [childRefs, onChangeIndex]
  );

  const handleKeyUp = useCallback(
    (e) => {
      if(isDialogOpen){
        return;
      }
      let index = activeChild;
      switch (e.key) {
        case "ArrowRight":
          index = (index+1 < React.Children.count(children))? index+1 : 0
          
          if (activeChild !== index) {
            ReactDOM.findDOMNode(childRefs[index].current).scrollIntoView({
                   behavior: "auto",
                    block: "start",
                    inline: "center",
                        })
            handleTabChange(index);
          }
          break;
        case "ArrowLeft":
          index= (index-1 >= 0)? index-1 : React.Children.count(children)-1 
       
          if (activeChild !== index) {
            ReactDOM.findDOMNode(childRefs[index].current).scrollIntoView({
              behavior: "auto",
                block: "start",
                inline: "center",
                    })
            handleTabChange(index);
          }
          break;
        default:
          break;
      }
    },
    [activeChild, children, handleTabChange]
  );

  const renderChildren = () => {
     return React.Children.map(children, (child, i) => {
      const childRef = React.createRef();

      childRefs[i] = childRef;

      return React.cloneElement(child, {
        index: i,
        onTabChange: handleTabChange,
        isActive: activeChild === i,
        ref: childRef,
      });
    });
  };

  useEffect(() => {
    document.addEventListener("keyup", handleKeyUp);
    if(isRecreated){
      childRefs[current_Tab].current.scrollIntoView({
      behavior: "auto",
      block: "start",
      inline: "center",
    });}
    return () => document.removeEventListener("keyup", handleKeyUp);
  }, [handleKeyUp]);


  return <div className={prefixCls}>{renderChildren()}</div>;
  });

Tabs.propType = {
  onChangeIndex: PropTypes.func,
  children: PropTypes.array.isRequired,
  current_Tab:PropTypes.func,
  isRecreated:PropTypes.bool,
  isDialogOpen:PropTypes.bool,
};

Tabs.defaultProps = {
 isRecreated:false
};

export default Tabs;
