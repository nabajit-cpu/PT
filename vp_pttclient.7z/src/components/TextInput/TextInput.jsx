import React, { useState, useEffect } from "react";
import PropTypes from "prop-types";
import classnames from "classnames";
import "./TextInput.less";

const prefixCls = "jps-text-input";

const TextInput = ({
  focusColor,
  label,
  index,
  inputType,
  disabledInput,
  onFocusChange,
  forwardedRef,
  onChange,
  enableTabSwitching,
  initialValue,
  labelText,
  footer,
  footerText,
  isLarge,
  initValue,
  onLimit,
  isValidationReq,
  validationTextLength,
  ...props
}) => {
  const [isFocused, setIsFocused] = useState(false);
  const [caretPosition, setCaretPosition] = useState(0);
  const [value, setValue] = useState(initialValue);
  var textRef;
  const handleKeyUp = (event) => {
    if (enableTabSwitching) {
      if (
        (event.key === "ArrowLeft" && caretPosition !== 0) ||
        (event.key === "ArrowRight" && caretPosition !== value.length)
      ) {
        event.stopPropagation();
        event.nativeEvent.stopImmediatePropagation();
      }
    } else {
      event.stopPropagation();
      event.nativeEvent.stopImmediatePropagation();
    }
    setCaretPosition(event.target.selectionStart);
  };

  const handleChange = (event) => {
    if(isValidationReq && event.target.value.length>validationTextLength){
      if(onLimit){
        onLimit();
      }
      return;
    }
    setValue(event.target.value);
    onChange(event);
  };

  useEffect(() => {
    setValue(initValue);
  }, [initValue]);

  const handleFocusChange = (isFocused) => {
    //const input = forwardedRef.current;
    setIsFocused(isFocused);
    if (isFocused) {
      // setInp(label);

      onFocusChange(index);
      //  input.focus();
      if (!disabledInput) {
        textRef.focus();
        textRef.selectionStart = textRef.selectionEnd = value.length;
      }
      // Without this, it will just focus at position 0
      // requestAnimationFrame(() => {
      //   input.selectionStart = caretPosition;
      // })
    }
  };

  const itemCls = classnames([prefixCls, isFocused && `${prefixCls}--focused`]);
  const labelCls = `${prefixCls}-label`;
  const inputCls = `${prefixCls}-input`;
  const valueCls = `${prefixCls}-value`;

  return (
    <div
      tabIndex="0"
      ref={forwardedRef}
      className={itemCls}
      style={isLarge ? { backgroundColor: isFocused ? focusColor : "#FFFFFF" } :
        {
          backgroundColor: isFocused ? focusColor : "#FFFFFF"
        }}
      onFocus={() => handleFocusChange(true)}
      onBlur={() => handleFocusChange(false)}
    >
      {labelText ? (
        <label className={labelCls}>{labelText}</label>
      ) : (
        <label className={labelCls} data-l10n-id={label}></label>
      )}

      {disabledInput ?
        <span className={inputCls}>{disabledInput}</span>
      :
        <input
          autofocus
          ref={(input) => (textRef = input)}
          type={inputType}
          className={inputCls}
          onChange={handleChange}
          onFocus={() => handleFocusChange(true)}
          onKeyUpCapture={handleKeyUp}
          value={value}
          {...props}
        />
      }
      {
        footerText ? (
          <label className={labelCls}>{footerText}</label>
        ) : null
      }
      {
        footer ? (
          <label className={labelCls} data-l10n-id={footer}></label>
        ) : null
      }

    </div>
  );
};

TextInput.defaultProps = {
  inputType: "text",
  focusColor: "#0E4B9B",
  enableTabSwitching: false,
  initialValue: "",
  labelText: null,
  isLarge: false,
  initValue: null,
  footerText: null,
  isValidationReq: false,
  validationTextLength: 8,
  onLimit: null,
  onChange: () => {},
};

TextInput.propTypes = {
  label: PropTypes.string,
  footer: PropTypes.string,
  focusColor: PropTypes.string,
  forwardedRef: PropTypes.oneOfType([
    PropTypes.func,
    PropTypes.shape({ current: PropTypes.any }),
  ]),
  index: PropTypes.number,
  inputType: PropTypes.string,
  onFocusChange: PropTypes.func,
  onChange: PropTypes.func,
  enableTabSwitching: PropTypes.bool,
  initialValue: PropTypes.string,
  labelText: PropTypes.string,
  initValue: PropTypes.string,
  isValidationReq: PropTypes.bool,
  disabledInput: PropTypes.string,
  isLarge: PropTypes.bool,
  footerText: PropTypes.string,
  initValue: PropTypes.string,
  onLimit: PropTypes.func,
  validationTextLength: PropTypes.number
};

export default React.forwardRef((props, ref) => (
  <TextInput forwardedRef={ref} {...props} />
));
