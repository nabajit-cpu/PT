import React from 'react';
import PropTypes from 'prop-types';
import { useFocus } from '../../hooks';

import './ProgressBar.less';

const prefixCls = 'pbar';

const ProgressBar = React.memo(
  props => {
    const {
      percentage,
      focusColor,
      forwardedRef,
      index,
      onFocusChange
    } = props;

    const handleFocusChange = isNowFocused => {
      if (isNowFocused) {
        onFocusChange(index);
      }
    }

    const isFocused = useFocus(forwardedRef, handleFocusChange, false);
    let totalValue = 0;
    let bars = percentage && percentage.length && percentage.map(function(item, i) {
    if(item.value > 0) {
        totalValue += item.value;
        return (
          <div className="bar"
            style={{'backgroundColor': item.color, 'width': item.value + '%'}}
            key={i}
          />
        )
      }
    },  this);

    return (
      <div
        tabIndex="0"
        className={prefixCls}
        style={{ backgroundColor: isFocused ? focusColor : '#ffffff' }}
        ref={forwardedRef}
      >
        <div className="multicolor-bar">
          <div className="bars">
            {bars === ''?'':bars}
            {totalValue === 100 || percentage.length === 1? null :
              <div className="bar"
              style={{'backgroundColor': "#F0F0F0", 'width': 100-totalValue + '%'}}
            />}
          </div>
        </div>
      </div>
    );
  }
);

ProgressBar.propTypes = {
  percentage: PropTypes.array,
  focusColor: PropTypes.string,
};

ProgressBar.defaultProps = {
  focusColor: "#0E4B9B",
};

export default React.forwardRef((props, ref) => (
  <ProgressBar forwardedRef={ref} {...props} />
));
