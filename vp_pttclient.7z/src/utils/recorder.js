import Connection from "./connection";
import MessageHelper from "./message_helper";
import Logger from "./logger";
import { encode } from "notepack.io";
import { ConnectionStates, MediaStates } from "./states";

const TAG = "Recorder :: ";
const constraints = { audio: true };
const RECORDING_TIMER = 1500;
let Recorder = {
  mediaRecorder: null,
  chunks: [],
  receiverID: "",
  userId: "",
  channelType: 0,
  callback: null,
  isStopByUser: false,
  isStartByUser: false,
  recordingTimer: null,
  stream: null,

  initMediaRecorder: function () {
    Logger.log(TAG, "initMediaRecorder");
    return new Promise((resolve, reject) => {
      if (navigator.mediaDevices) {
        Logger.log(TAG, constraints);
        navigator.mediaDevices.getUserMedia(constraints).then((stream) => {
          resolve(stream);
        });
      } else {
        reject();
        Logger.log(TAG, " initMediaRecorder mediaDevices not supported");
      }
    });
  },

  startRecording: function (userId, receiverID, channelType, callback, isRepeat) {
    Logger.log(TAG, "start Recording");
    this.initMediaRecorder()
      .then((stream) => {
        Logger.log(TAG, "stream Recording", stream);
        this.chunks = [];
        this.stream = stream;
        const options = {
          audioBitsPerSecond: 48000,
          mimeType: "audio/ogg",
        };
        this.mediaRecorder = new MediaRecorder(stream, options);
        this.mediaRecorder.start();
        this.mediaRecorder.onstart = this.onRecordingStart.bind(this);
        this.mediaRecorder.onstop = this.onRecordingStop.bind(this);
        this.mediaRecorder.ondataavailable = this.onRecordingDataAvailable.bind(this);
        this.receiverID = receiverID;
        this.channelType = channelType;
        this.callback = callback;
        this.userId = userId;
        if (!isRepeat) {
          this.isStopByUser = false;
          this.isStartByUser = true;
        }
      })
      .catch((e) => {
        Logger.log(TAG, e.message);
      });
  },

  startRecordingTimer: function () {
    if (!this.isStopByUser) {
      this.recordingTimer = setTimeout(this.recordingTimerCallback.bind(this), RECORDING_TIMER);
    }
  },

  stopRecordingTimer: function () {
    if (this.recordingTimer) {
      clearTimeout(this.recordingTimer);
      this.recordingTimer = null;
    }
  },

  recordingTimerCallback: function () {
    if (this.mediaRecorder) {
      this.mediaRecorder.stop();
    }
  },

  stopRecording: function () {
    if (this.mediaRecorder && this.mediaRecorder.state == "recording") {
      this.isStopByUser = true;
      this.mediaRecorder.stop();
      this.stopRecordingTimer();
    }
  },

  onRecordingStart: function (e) {
    Logger.log(
      TAG,
      " mediaRecorder onRecordingStart mediaRecorder.state",
      this.mediaRecorder.state
    );
    this.startRecordingTimer();
    if (this.isStartByUser) {
      window.dispatchEvent(
        new CustomEvent("MediaStates_" + MediaStates.StartTalking, {
          detail: {
            userID: this.userId,
            groupId: this.groupId,
          },
        })
      );
    }
  },

  onRecordingStop: function (e) {
    Logger.log(TAG, " mediaRecorder onRecordingStop ");
    var chunks = this.chunks;
    if (!this.isStopByUser) {
      this.isStartByUser = false;
      this.startRecording(this.userId, this.receiverID, this.channelType, this.callback, true);
    } else {
      window.dispatchEvent(
        new CustomEvent("MediaStates_" + MediaStates.StopTallking, {
          detail: {
            userID: this.userId,
            groupId: this.groupId,
          },
        })
      );
    }
    const audioBlob = new Blob(chunks, { type: "audio/ogg; codecs=opus" });
    this.getArryBufferFromBlob(audioBlob).then((data) => {
      Connection.send(
        MessageHelper.createAudioMessage(
          this.userId,
          this.receiverID,
          this.channelType,
          encode(data)
        )
      );
      if (this.isStopByUser) {
        setTimeout(() => {
          //send Stop ACK
          Connection.send(
            MessageHelper.createAckStopMessage(this.userId, this.receiverID, this.channelType)
          );
        }, 200);
      }
    });
  },

  onRecordingDataAvailable: function (e) {
    Logger.log(TAG, " mediaRecorder ondataavailable. e.data", e.data);
    Logger.log(
      TAG,
      " mediaRecorder ondataavailable. mediaRecorder.state",
      this.mediaRecorder.state
    );
    this.chunks.push(e.data);
  },

  getArryBufferFromBlob: function (blobData) {
    return new Promise((resolve, reject) => {
      var arrayBuffer;
      var fileReader = new FileReader();
      fileReader.onload = function (event) {
        arrayBuffer = event.target.result;
        resolve(arrayBuffer);
      };
      fileReader.readAsArrayBuffer(blobData);
    });
  },
};

export default Recorder;
