export default class Message {
  constructor(message) {
    this.userId = message[2];
    this.isGroup = message[0] == 0;
    this.groupId = message[3];
    this.messageType = message[1];
    this.payLoad = message[4];
  }

  getSenderID() {
    if (this.messageType == 3) {
      var senderId = this.userId;
      senderId = senderId.split("_");
      this.company = senderId[0];
      return senderId[1];
    }
    return null;
  }

  getCompanyName() {
    var senderId = this.userId;
    senderId = senderId.split("_");
    return senderId[0];
  }
}
