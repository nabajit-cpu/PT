import MessageHelper from "./message_helper";
import { MessageType, ChannelType } from "./channel_message_Type";
import { encode, decode } from "notepack.io";
import Recorder from "./recorder";
import Logger from "./logger";
import Message from "./message";
import { ConnectionStates, MediaStates } from "./states";
import Player from "./player";

const TAG = "Connection :: ";
const wssUrl = "ws://3.111.63.84:3000"; //"wss://router-lite.voiceping.info";  // "ws://65.2.5.50:3000";
const WEBSOCKET_STATE = {
  InvalidState: 0,
  ReadyState: 1,
  SendingState: 2,
};
let Connection = {
  audioReceiveState: false,
  callBack: null,
  //WebSocket Object
  webSocket: null,
  userId: "",
  socketState: WEBSOCKET_STATE.InvalidState,
  audioData: [],
  connect: function (userId, deviceID, callback, socketUrl = wssUrl) {
    this.webSocket = new WebSocket(socketUrl, [userId, deviceID]);
    this.addSocketEventListner();
    this.callBack = callback;
    this.userId = userId;
  },

  addSocketEventListner: function () {
    if (this.webSocket) {
      this.webSocket.onopen = this.onopen.bind(this);
      this.webSocket.onmessage = this.onmessage.bind(this);
      this.webSocket.onerror = this.onerror.bind(this);
      this.webSocket.onclose = this.onclose.bind(this);
    } else {
      Logger.log(TAG, "webSocket object is not there please connect first");
    }
  },
  removeSocketEventListner: function () {
    this.webSocket.onopen = null;
    this.webSocket.onmessage = null;
    this.webSocket.onerror = null;
    this.webSocket.onclose = null;
  },

  onopen: function (e) {
    Logger.log(TAG, "PushToTalk webSocket onopen now user can send data ", e);
    this.socketState = WEBSOCKET_STATE.ReadyState;
    this.callBack && this.callBack();
    this.callBack = null;
    this.send(MessageHelper.createConnectionMessage(this.userId));
    var dummyAckStart = MessageHelper.createAckStartMessage(
      this.userId,
      "00000",
      ChannelType.PRIVATE,
      new Date().getTime()
    );
    if (dummyAckStart != null) {
      this.send(dummyAckStart);
    }
  },

  onmessage: function (message) {
    //Logger.log(TAG, "PushToTalk webSocket onmessage message ", message);
    if (message.data) {
      //Logger.log(TAG, "PushToTalk webSocket onmessage message ", message.data.type);
      Recorder.getArryBufferFromBlob(message.data).then((data) => {
        //Logger.log(TAG, "PushToTalk webSocket onmessage dataArrayBuffer ", data);
        Logger.log(TAG, "PushToTalk webSocket onmessage decode message ", decode(data));
        this.parseSocketMessage(decode(data));
      });
    }
  },

  parseSocketMessage: function (messageArr) {
    var message = new Message(messageArr);
    Logger.log(TAG, "parseSocketMessage  ==>message ", message);
    switch (message.messageType) {
      case MessageType.START_TALKING:
        this.audioData = [];
        this.audioReceiveState = true;
        Player.startPlayer();
        window.dispatchEvent(
          new CustomEvent("MediaStates_" + MediaStates.StartListen, {
            detail: {
              userID: message.userId,
              groupId: message.groupId,
            },
          })
        );
        break;
      case MessageType.STOP_TALKING:
        // this.audioReceiveState = false;
        //Player.playRecordedAudio();

        setTimeout(() => {
          window.dispatchEvent(new CustomEvent("MediaStates_" + MediaStates.AudioPlayerStop));
        }, Player.DataBuffer.length * 1500);
        window.dispatchEvent(
          new CustomEvent("MediaStates_" + MediaStates.StopListen, {
            detail: {
              userID: message.userId,
              groupId: message.groupId,
            },
          })
        );
        break;
      case MessageType.ACK_START:
        if (message.groupId === "00000") {
          window.dispatchEvent(
            new CustomEvent("ConnectionStates_" + ConnectionStates.Connected, {
              detail: {
                userID: message.userId,
              },
            })
          );
        } else {
          Recorder.startRecording(
            message.userId,
            message.groupId,
            message.isGroup ? ChannelType.GROUP : ChannelType.PRIVATE
          );
        }
        break;
      case MessageType.ACK_END:
        break;
      case MessageType.AUDIO:
        try {
          Logger.log(
            TAG,
            "parseSocketMessage MessageType ==> AUDIO data ",
            decode(message.payLoad)
          );
          var audioURL = URL.createObjectURL(
            new Blob([decode(message.payLoad)], { type: "audio/ogg; codecs=opus" })
          );
          Logger.log(TAG, "parseSocketMessage MessageType ==> AUDIO audioURL ", audioURL);
          Player.addTrack(audioURL);
          Logger.log(
            TAG,
            "parseSocketMessage MessageType ==> Player.playerState ",
            Player.playerState
          );
          if (Player.playerState != 2 && Player.playerState != 0) {
            Player.playRecordedAudio();
          }
        } catch (e) {
          console.log(e.message);
        }

        break;
      case MessageType.DUPLICATE_CONNECT:
        window.dispatchEvent(new CustomEvent("ConnectionStates_" + ConnectionStates.Invalid));
        break;
    }
  },

  onerror: function () {
    this.socketState = WEBSOCKET_STATE.InvalidState;
    this.removeSocketEventListner();
    Logger.log(TAG, "PushToTalk webSocket onerror  ");
  },

  onclose: function () {
    this.socketState = WEBSOCKET_STATE.InvalidState;
    this.removeSocketEventListner();
    this.callBack && this.callBack();
    this.callBack = null;
    this.webSocket = null;
    window.dispatchEvent(new CustomEvent("ConnectionStates_" + ConnectionStates.Invalid));
    Logger.log(TAG, "PushToTalk webSocket onclose  ");
  },

  send: function (data) {
    Logger.log(TAG, " send", data);
    Logger.log(TAG, " send decode data ", decode(data));
    if (this.webSocket) {
      this.webSocket.send(data);
    }
  },

  disconnect: function (callback) {
    if (this.webSocket) {
      this.webSocket.close();
      this.callBack = callback;
    }
  },

  isConnected: function () {
    return this.socketState == WEBSOCKET_STATE.ReadyState;
  },
};
export default Connection;
