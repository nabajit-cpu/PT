export const ConnectionStates = {
  Invalid: 0,
  Connected: 1,
  Joined: 2,
};

export const MediaStates = {
  Invalid: 0,
  StartTalking: 1,
  StopTallking: 2,
  StartListen: 3,
  StopListen: 4,
  AudioPlayerStop: 5,
};
