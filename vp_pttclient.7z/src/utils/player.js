import Connection from "./connection";
import MessageHelper from "./message_helper";
import Logger from "./logger";
import { encode } from "notepack.io";
import { ConnectionStates, MediaStates } from "./states";

const audioContext = new AudioContext();
const TAG = "Player :: ";
const PLAYER_STATES = {
  Invalid: 0,
  Ready: 1,
  Playing: 2,
  Stoped: 3,
};

let Player = {
  DataBuffer: [],
  playerState: PLAYER_STATES.Invalid,
  audioContainer: null,
  audioElement: null,
  timeOffset: 0,
  // play: async function () {
  //   Logger.log(TAG, "Play DataBuffer.length ", this.DataBuffer.length);
  //   if (this.DataBuffer.length > 0) {
  //     var arrayBuffer = this.DataBuffer.shift();
  //     Logger.log(TAG, "Play arrayBuffer ", arrayBuffer);
  //     var buffer = await audioContext.decodeAudioData(arrayBuffer);
  //     Logger.log(TAG, "Play arrayBuffer ", buffer);
  //     const source = audioContext.createBufferSource();
  //     source.buffer = buffer;
  //     source.connect(audioContext.destination);
  //     source.start();
  //     this.playerState = PLAYER_STATES.Playing;
  //     Logger.log(TAG, "Play playerState ", this.playerState);
  //     source.onended = async () => {
  //       if (this.DataBuffer.length > 0) {
  //         var arrayBuffer = this.DataBuffer.shift();
  //         var buffer = await audioContext.decodeAudioData(arrayBuffer);
  //         source.buffer = buffer;
  //         source.start();
  //       } else {
  //         this.playerState = PLAYER_STATES.Stoped;
  //         window.dispatchEvent(new CustomEvent("MediaStates_" + MediaStates.AudioPlayerStop));
  //       }
  //     };
  //   }
  // },

  addTrack: function (audioUrl) {
    this.DataBuffer.push(audioUrl);
  },

  startPlayer: function () {
    var pttDiv = document.getElementById("ptt_div");
    if (!pttDiv) {
      this.audioContainer = document.createElement("div");
      this.audioContainer.id = "ptt_div";
      this.audioContainer.classList.add("hidden");
      this.audioElement = document.createElement("audio");
      this.audioElement.id = "ptt_audio";
      this.audioElement.classList.add("hidden");
      this.audioContainer.appendChild(this.audioElement);
      document.body.appendChild(this.audioContainer);
    }
    this.playerState = PLAYER_STATES.Ready;
  },

  playRecordedAudio: function () {
    if (this.DataBuffer.length > 0) {
      if (
        (this.playerState == PLAYER_STATES.Ready || this.playerState == PLAYER_STATES.Stoped) &&
        this.audioElement
      ) {
        var audioURL = this.DataBuffer.shift();
        this.audioElement.removeAttribute("src");
        this.audioElement.load();
        this.audioElement.src = audioURL;
        Logger.log(TAG, " playRecordedAudio  audioURL", audioURL);
        this.audioElement.load();
        this.audioElement.play();
        this.playerState = PLAYER_STATES.Playing;
        this.audioElement.onended = () => {
          this.playerState = PLAYER_STATES.Stoped;
          if (this.DataBuffer.length > 0) {
            this.playRecordedAudio();
          }
        };
      } else {
        this.startPlayer();
        var self = this;
        setTimeout(() => {
          self.playRecordedAudio();
        }, 500);
      }
    }
  },
};
export default Player;
