import Connection from "./connection";
import Recorder from "./recorder";
import MessageHelper from "./message_helper";
import Logger from "./logger";
import { ConnectionStates, MediaStates } from "./states";

const TAG = "PushToTalk :: ";
const CID = "cl00";
const APPID = "AU109042020";
const CRMID = "0";
const DT = "kdc";
const HOSTID_HOSTV = "0";
const DCV = "1.2.3";
const clientIdDelimiter = "_";
var UNIQUEID = "345672398123567";
let PushToTalk = {
  userId: "",
  company: "",

  clientID:
    CID +
    clientIdDelimiter +
    APPID +
    clientIdDelimiter +
    CRMID +
    clientIdDelimiter +
    DT +
    clientIdDelimiter +
    HOSTID_HOSTV +
    clientIdDelimiter +
    DCV +
    clientIdDelimiter +
    UNIQUEID,
  init: function () {
    Logger.log(TAG, "Init PTT");
    if (navigator.mozMobileConnections) {
      var req = navigator.mozMobileConnections[0].getDeviceIdentities();
      req.onsuccess = function () {
        UNIQUEID = req.result.imei;
      };
    }
  },
  connect: function (userId, companyName, callback, url) {
    this.userId = userId;
    this.company = companyName;
    Connection.connect(this.getFullUserId(), this.clientID, callback, url);
  },
  disconnect: function (callback) {
    Connection.disconnect(callback);
  },
  getConnectionState: function () {
    return Connection.socketState;
  },

  startTalking: function (receiverID, channelType, callback, destinationPath) {
    //send start ACK
    Connection.send(
      MessageHelper.createAckStartMessage(
        this.getFullUserId(),
        this.getFullId(receiverID),
        channelType,
        new Date().getTime()
      )
    );
  },

  stopTalking: function () {
    Recorder.stopRecording();
  },

  joinGroup: function (groupId) {
    if (Connection.isConnected()) {
      Connection.send(
        MessageHelper.createSubscribeMessage(this.getFullUserId(), this.getFullId(groupId))
      );
      window.dispatchEvent(
        new CustomEvent("ConnectionStates_" + ConnectionStates.Joined, {
          detail: {
            userID: this.getFullUserId(),
            groupID: this.getFullId(groupId),
          },
        })
      );
    } else {
      Logger.log(TAG, "join Gp Not connected to server");
    }
  },

  leaveGroup: function (groupId) {
    Connection.send(
      MessageHelper.createUnsubscribeMessage(this.getFullUserId(), this.getFullId(groupId))
    );
    window.dispatchEvent(
      new CustomEvent("ConnectionStates_" + ConnectionStates.Connected, {
        detail: {
          userID: this.getFullUserId(),
          groupID: this.getFullId(groupId),
        },
      })
    );
  },

  getFullUserId: function () {
    return this.company + "_" + this.userId;
  },

  getFullId: function (id) {
    return this.company + "_" + id;
  },

  mute: function (targetId, channelType) {},

  unMute: function (targetId, channelType) {},

  muteAll: function () {},

  unMuteAll: function () {},

  playRecordedAudio: function () {
    Recorder.playRecordedAudio();
  },
};

PushToTalk.init();
export default PushToTalk;
