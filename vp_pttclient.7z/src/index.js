import ComponentManager from "./ComponentManager/ComponentManager.min";
import React from "react";
import EmitterHandler from "./ComponentManager/CommonEmitter";
import loadable from "@loadable/component";
import "./index.css";

function handle(activity) {
  switch (activity.source.name) {
    case "settings":
      window.componentManager.startComponent(activity.source.data.url, { isBackEnabled: false }, 1);
      break;

    case "configure":
      // if(activity.source.data.section == 'volume'){
      //   const VolumeScreen = loadable(()=>import(/* webpackPrefetch: true */'./screens/Personalization/Sound/VolumeScreen'));
      //   window.componentManager.registerComponent("/volume",<VolumeScreen/>);
      //   window.componentManager.startComponent("/volume", { isBackEnabled: false }, 1);
      // }

      // if(activity.source.data.section == 'geolocation'){
      //   const GeoLocation = loadable(()=>import(/* webpackPrefetch: true */'./screens/NetworkAndConnectivity/Geolocation/Geolocation'));
      //   window.componentManager.registerComponent("/geolocation",<GeoLocation/>);
      //   window.componentManager.startComponent("/geolocation", { isBackEnabled: false }, 1);
      // }

      // if(activity.source.data.section == 'downloads'){
      //   const Downloads = loadable(()=>import(/* webpackPrefetch: true */'./screens/Device/Download/DownloadScreen'));
      //   window.componentManager.registerComponent("/downloads",<Downloads/>);
      //   window.componentManager.startComponent("/downloads", { isBackEnabled: false }, 1);
      // }

      //TODO: for tone-manager ui
      break;
    default:
      break;
  }
}

let appElement = "";

if (typeof window !== "undefined") {
  //var actHandler = ActivityHandler.handle.bind(ActivityHandler);
  if (!window.componentManager) {
    window.componentManager = ComponentManager.getInstance(); // for CM2.0  webos
  }
  if (!window.emitterHandler) {
    window.emitterHandler = new EmitterHandler();
  }
  //const SettingsCache = settings_cache();
  //SettingsCache.getSettings(null)
  // Logger.setConfig({
  //   debug: false,
  //   error: true
  // });
  // var lock = navigator.mozSettings.createLock();
  // lock.get('debug.gaia.enabled').then((result) => {
  //   Logger.debug(TAG , "inside logger result= ",result['debug.gaia.enabled'])
  //   // Logger.configs.debug = result['debug.gaia.enabled'];
  //   Logger.setConfig({
  //     debug: result['debug.gaia.enabled'],
  //   });
  // }).catch(console.error.bind(console));
  var FontFaceObserver = require("fontfaceobserver");

  var font = new FontFaceObserver("JioType");
  font.load().then(function () {
    document.body.classList.toggle("fonts-loaded", true);
  });

  window.navigator.mozSetMessageHandler("activity", handle);
  require("./MainScreen/MainScreen");
  appElement = window.componentManager.startComponent("/Home");
  document.body.classList.toggle("large-text", window.navigator.largeTextEnabled);
  window.addEventListener("largetextenabledchanged", () => {
    document.body.classList.toggle("large-text", window.navigator.largeTextEnabled);
  });
}

export default appElement;
