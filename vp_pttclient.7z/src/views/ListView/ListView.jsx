import React, { useCallback, useEffect, useState } from "react";
import ReactDOM from "react-dom";
import PropTypes from "prop-types";
import "./ListView.css";

const prefixCls = "jps-list-view";
const ListView = React.memo((props) => {
  const itemRefs = [];
  let index= -1;

  const { children, onChangeIndex, isActive, callback, currentIndex, isRecreated, isDialogOpen, disabledCallback, disableListRotation } = props;
  const [activeItem, setActiveItem] = useState(currentIndex);

  const handleChangeIndex = (itemIndex) => {
    setActiveItem(itemIndex);
    onChangeIndex(itemIndex);
  //  ReactDOM.findDOMNode(itemRefs[itemIndex].current).scrollIntoView({block: "end", inline: "nearest"});
  };

  const setFocusToIndex = useCallback(
    (index) => {
      ReactDOM.findDOMNode(itemRefs[index].current).scrollIntoView({block: "end", inline: "nearest"});
      ReactDOM.findDOMNode(itemRefs[index].current).focus()
    },
    [itemRefs]
  );

  const handleKeyDown = useCallback(
    (e) => {
      let index = activeItem;
      let appElement = null;
      if (!isActive) {
        return;
      }

      if (isDialogOpen) {
        // e.preventDefault(); // Let's stop this event.
        // e.stopPropagation();
      } else {
      switch (e.key) {
        case "ArrowUp":
          // looping to bottom
          index = index - 1;
          if(index < 0){
            if(disableListRotation) {
              break;
            }
            else {
              index = itemRefs.length-1;
            }
          }
          ReactDOM.findDOMNode(itemRefs[index].current).scrollIntoView({behaviour: "smooth",block: "start", inline: "nearest"});
          setFocusToIndex(index);
          break;
        case "ArrowDown":
          // looping to top
          index = index + 1 < itemRefs.length ? index + 1 : 0;
          if(index==0){
            ReactDOM.findDOMNode(itemRefs[index].current).scrollTop=0
           // setActiveItem(0);
            setFocusToIndex(0);
          }else{
            ReactDOM.findDOMNode(itemRefs[index].current).scrollIntoView({block: "end",behaviour: "smooth", inline: "nearest"});
            setFocusToIndex(index);
          }
            
          
         // setFocusToIndex(index);
          break;
        case "Enter":
        case "Accept":
          if(itemRefs[index].current){
            // Logger.debug(TAG , itemRefs[index].current.getAttribute('itemdisabled'));
            if(itemRefs[index].current.getAttribute('itemdisabled')==='enabled'){
              props["callback"](itemRefs[index].current.id);
            }
            else{
              if(itemRefs[index].current.getAttribute('itemdisabled')==='disabled'){
                props["disabledCallback"](itemRefs[index].current.id);
              }
            }
          }
          break;
        default:
          break;
        }
      }
    },
    [isActive, activeItem, setFocusToIndex, itemRefs]
  );

  useEffect(() => {
    document.addEventListener("keydown", handleKeyDown);
    return () => document.removeEventListener("keydown", handleKeyDown);
  }, [handleKeyDown]);

  useEffect(() => {
    if (isActive) {
      if(index < activeItem){
        setActiveItem(index);
        setFocusToIndex(index);
      }else{
        setFocusToIndex(activeItem);
      }
    }
  }, [isActive, setFocusToIndex, activeItem]);

  useEffect(() => {
    // Logger.debug(TAG , "JPS: isRecreated = "+isRecreated);
    // Logger.debug(TAG , "JPS: currentIndex ="+currentIndex);
    if(isRecreated){
      setActiveItem(currentIndex);
      setFocusToIndex(currentIndex);
    }
  }, [isRecreated, currentIndex]);

  const renderChildren = () => {
    index = -1;
    return React.Children.map(children, (child) => {
      // Don't focus on empty child or separators
      if (child === null || child.props.separatorText != null) {
        return child;
      }
      index++;
      const newRef = React.createRef();
      itemRefs[index] = newRef;
      return React.cloneElement(child, {
        index,
        onFocusChange: handleChangeIndex,
        ref: newRef,
      });
    });
  };

    return <div className={prefixCls} >{renderChildren()}</div>;


});

ListView.propTypes = {
  children: PropTypes.array.isRequired,
  onChangeIndex: PropTypes.func,
  // Refocus on tab change
  isActive: PropTypes.bool,
  callback: PropTypes.func,
  isRecreated: PropTypes.bool,
  currentIndex: PropTypes.func,
  isDialogOpen: PropTypes.bool,
  disableListRotation: PropTypes.bool,
};

ListView.defaultProps = {
  onChangeIndex: () => {},
  isActive: true,
  isRecreated: false,
  currentIndex: 0,
  isDialogOpen: false,
  disableListRotation: false
};

export default ListView;
