import React, { Component } from "react";
import PropTypes from "prop-types";

import Header from "../../components/Header/Header";
import ListView from "../../views/ListView/ListView";
import RadioButton from "../../components/RadioButtonItem/RadioButtonItem";
import { SoftKeyProvider } from "../../components/SoftKey/SoftKeyProvider";
import "./RadioListView.less";
/*Can be used as a screen or as a component
  properties ={
    cskText: "OK",
    headerText: "Select",
    onSelect: this.onSelect,
    checkedItem: this.state.checkedItem,
    radioLabels: this.debuggerOptions,
  };
  startComponent("/radiolistview",properties,this.props.identifier,this.state, this.props);
*/

class RadioListView extends Component{
  constructor(props) {
    super(props);

    this.onCancel = this.onCancel.bind(this);
    this.onPressed = this.onPressed.bind(this);
  }

  state={
    checkedIndex: 0
  }

  onPressed(id){
    this.props.onSelect(id);
    this.onCancel();
  };

  onCancel(){
    // Logger.debug(TAG ,  "onCancel");
    if(this.props.identifier){
      window.componentManager.finish(this.props.identifier);
    }else{
      this.props.leftCallback();
    }
  };

  renderChildren(){
    // Logger.debug(TAG , "Radio labels ", JSON.stringify(this.props.radioLabels));

    return this.props.radioLabels.map((labelData, i) => {
      if(this.props.checkedItem === labelData.label || (labelData.primaryText && this.props.checkedItem === labelData.primaryText)){
      if(!(i == this.state.checkedIndex)){
        this.setState({checkedIndex:i})
      }
    }
      let secondaryText1 = null;
      if(labelData.secLabel){
        secondaryText1 = labelData.secLabel;
      }
      return (
        <RadioButton
          key={`key-${i}`}
          primary={labelData.label}
          primaryText={labelData.primaryText}
          secondary={secondaryText1}
          secondaryText={labelData.secondaryText}
          isChecked={this.props.checkedItem === labelData.label || (labelData.primaryText && this.props.checkedItem === labelData.primaryText)}
          isEnabled={this.props.checkedItem === labelData.label || (labelData.primaryText && this.props.checkedItem === labelData.primaryText)}
          id={labelData.label ? labelData.label : labelData.primaryText}
        />
      );
    });
  }

  render(){
    // Logger.debug(TAG , "radiolist render, checked item= ",this.state.checkedIndex)
    return(
      <div>
        <Header text={this.props.headerText} />
        <SoftKeyProvider
         center= {this.props.cskText ? this.props.cskText : ""}
         left= "cancel"
         leftCallback={this.onCancel}
         backCallback={this.onCancel}
        >
          <div className="content">
            <ListView 
            callback={this.onPressed}
            currentIndex={this.state.checkedIndex}
            isRecreated={true}
            >
              {this.renderChildren()}
            </ListView>
          </div>
        </SoftKeyProvider>
      </div>
    )
  }
}

RadioListView.propType = {
  cskText: PropTypes.string,  //Center button text
  /*Left softkey callback if not starting as a component
   always considered as cancel key*/
  leftCallback: PropTypes.func,
  headerText: PropTypes.string,
  onSelect: PropTypes.func.isRequired, //Callback to get the selected item
  checkedItem: PropTypes.string.isRequired, //Primary Label of the current selected item

  /*Labels for radio button list in key value  pairs
  [{label: PrimaryText, secLabel: SecondaryText}]*/
  radioLabels: PropTypes.array.isRequired,

};

RadioListView.defaultProps = {
  cskText: null,
  headerText: "select",
  radioLabels: [
    { label: "on", secLabel: null, primaryText: null, secondaryText: null },
    { label: "off", secLabel: null, primaryText: null, secondaryText: null },
  ],
  leftCallback: ()=>{}
};

window.componentManager.registerComponent("/radiolistview", <RadioListView/>);
export default  RadioListView;